# Backlog V1

> Gerado de `backlog.json` por `tools/gerar_documentacao.py --write`. Edite o JSON.

Status: todo = não iniciado; done exige evidência. Não confundir planejamento com implementação.

## EP01 — Recorte verificável e governança

Transformar a pesquisa concluída em um lote candidato real e uma execução rastreável, sem presumir liberação dos materiais.

### V1-001 — Mapear conteúdo e cenários do APK de avaliação

**done · V1 · M**

Como responsável pelo produto, quero avaliar o app inteiro com conteúdo real e lacunas explícitas, cenário por cenário, para orientar o desenvolvimento antes de o produto estar completo.

Dependências: nenhuma

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md; docs/execucao/v1/decisoes-piloto.md; docs/conteudo/opcoes-apis-exercicios.md

Critérios de aceite:

- Manifesto cobre os candidatos existentes e seus IDs PR/N/componentes, versões, fontes, públicos e ambientes, mantendo casa, praça, academia, idosos e cuidadores distintos; não reduzir a cobertura a uma amostra arbitrária
- Matriz relaciona os cenários R01-R18 do APK a capacidades e conteúdo disponíveis, incompletos, bloqueados ou ainda não implementados; avaliação ampla não implica funcionamento simulado
- Autor e esposa avaliam o app por cenários; idade, elegibilidade, equipamento e apoio disponíveis não são inferidos
- Cada material tem estado consulta/prática/bloqueado e motivo; ausência de foto/vídeo e de instrução são separadas, sem conteúdo inventado nem mídia sem direito de uso
- Alimentação contempla base ampla pesquisada, busca por texto, cadastro próprio real e origem distinta; custo prioriza gratuitas e referência de cerca deUS$19 em compra única, sem assinatura nem compra automática

Tarefas e subtarefas:

- V1-001-T01 — Inventariar a cobertura existente
  - Ler consolidação N01-N46 e seleção N15 de21/10, relacionando candidatos às evidências locais sem nova coleta sem pista
  - Listar autoria, dose, idioma, instrução, mídia disponível, direitos, público, equipamento, apoio e lacunas por ativo
  - Cobrir fontes alimentares existentes com contagens, versões, direitos e pendências, sem limitar o objetivo a poucos alimentos
- V1-001-T02 — Mapear avaliação por cenários e checkpoints de APK
  - Relacionar todos os cenários de treino, alimentação, públicos e ambientes ao estado real, com roteiro um de cada vez
  - Registrar busca e cadastro próprio de alimento, mídia conforme disponibilidade e ensino voltado à autonomia sem apagar requisitos da fonte
  - Definir checkpoints intermediários de APK e separar avaliação de interface, prática permitida e aceite integral da V1
  - Registrar a decisão de avaliar opções pagas de pagamento único e baixo custo; apresentar preço, licença e condições para aceite específico antes de qualquer contratação

Validação: Revisão do manifesto contra evidências locais; Conferir que componentes isolados não aparecem como programa integral; Conferir cobertura ampla, lacunas de mídia/instrução e estados de cenários contra os registros reais, sem fechar a história apenas por registrar decisões; python tools/validar_manifesto_piloto.py: fontes/ponteiros/hashes/cobertura/estados e matriz conferidos; nao homologacao de pratica

Entregas: content/manifests/pilot-candidates.json; docs/execucao/v1/matriz-cenarios.md; docs/execucao/v1/decisoes-piloto.md; docs/conteudo/opcoes-apis-exercicios.md; tools/validar_manifesto_piloto.py; docs/execucao/v1/verificacao-manifesto.json

Handoff: Registrar arquivos/contratos alterados, comandos e resultados reais, pendências e próxima história desbloqueada em docs/execucao/v1/diario.md; atualizar este JSON, regenerar backlog e conferir mapas versionados. Concluir somente com os critérios e evidências desta história.

### V1-002 — Aceitar a decisão Go e definir a fronteira de migração

**done · V1 · S**

Como mantenedor, quero um serviço com responsabilidade clara para evitar duas APIs escrevendo nos mesmos domínios.

Dependências: V1-001

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md

Critérios de aceite:

- Registrar decisão de implementar Go ou manter Fastify com custos, compatibilidade e motivação
- Novo serviço proposto em services/api; legado preservado e um único escritor por domínio
- Nenhuma migration de produção é executada nesta história

Tarefas e subtarefas:

- V1-002-T01 — Fechar ADR
  - Comparar prazo do Fastify com migração Go e objetivo de aprendizagem
  - Escolher versão Go suportada e gerenciador de migrations na data da execução
- V1-002-T02 — Congelar fronteira
  - Inventariar rotas e invariantes úteis do legado
  - Definir banco de teste isolado, estratégia de importação e rollback

Validação: Revisão do inventário de contratos; Checar ausência de dual write e de dependência obrigatória de Gemini

Entregas: ADR final; Mapa de compatibilidade e fronteiras

Handoff: Registrar arquivos/contratos alterados, comandos e resultados reais, pendências e próxima história desbloqueada em docs/execucao/v1/diario.md; atualizar este JSON, regenerar backlog e conferir mapas versionados. Concluir somente com os critérios e evidências desta história. 29/10: Go permanece escolhido; autor esclareceu preferência inicial por microserviços e pediu comparação para decidir execução. Autor escolheu detalhar microserviços por etapas; primeira prova de catálogo delimitada com gatesM0–M4, sem cutover/migração real aprovados; done histórico não é aprovação definitiva do monólito.

### V1-003 — Manter documentação arquitetural dinâmica no repositório

**done · V1 · S**

Como autor ou pessoa que clona o repositório, quero ler arquitetura, telas, HTTP, banco e progresso sem iniciar um serviço local.

Dependências: nenhuma

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md; docs/arquitetura/documentacao-dinamica.md; docs/arquitetura/swagger-go.md

Critérios de aceite:

- Markdown/Mermaid e tabelas versionados são legíveis no GitHub/editor sem iniciar ferramentas; backend externo é referência identificada, sem caminhos da máquina
- CI e geração local determinísticas, com validação de fontes/dependências/links e detecção de derivados desatualizados; publicação autorizada e execução remota conferidas em23/10.
- Go distingue comentários, registros literais e contrato gerado; status e achados não são concluídos automaticamente

Tarefas e subtarefas:

- V1-003-T01 — Gerar e validar documentação portátil
  - Ler código do clone e referência versionada do Fastify; gerar Markdown/Mermaid e backlog
  - Testar relocação, alteração real, mtime, links e fronteiras da detecção
- V1-003-T02 — Preparar atualização no GitHub
  - Regenerar/verificar em PR e push; versionar derivados só em job confiável da branch principal
  - Não usar token de escrita para executar código de PR; não contornar branch protection
- V1-003-T03 — Publicar e conferir automação quando autorizado
  - Enviar workflow/documentos ao remoto somente com autorização de publicação
  - Conferir execução real da CI e atualização do commit gerado; ajustar a política do remoto caso bloqueie

Validação: Geração/check e testes portáteis com biblioteca padrão; Sintaxe Mermaid validada com ferramenta separada; clone sem checkout externo; Execução real noGitHub em23/10: generate e version-generated concluídos com sucesso; derivados já atuais, sem commit artificial.

Entregas: docs/arquitetura/README.md e gerado/*.md; tools/gerar_documentacao.py e testes; .github/workflows/documentacao.yml

Handoff: 23/10: critério remoto resolvido com push autorizado e CI bem-sucedida; documentação permanece transversal, regenerar a cada alteração relevante. Não é início de outra história funcional.

## EP02 — Conteúdo, autoria e direitos

Um catálogo importável com proveniência, versões e uso permitido por ativo; pesquisa fechada não vira publicação automaticamente.

### V1-004 — Criar contrato editorial dos quatro tipos de conteúdo

**done · V1 · M**

Como curador, quero separar movimentos, instruções, mídia e programas completos para não atribuir ao conjunto direitos de uma única peça.

Dependências: V1-001

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md; docs/conteudo/README.md; docs/arquitetura/dominio-e-banco.md

Critérios de aceite:

- Source, autoria/contribuição, licença por ativo, evidência, versão, idioma, população, ambiente e apoio definidos
- Dosagem suporta tempo, repetições, distância, lado e pausas sem zeros fictícios
- Composição preserva origem de cada peça e não herda eficácia do programa original

Tarefas e subtarefas:

- V1-004-T01 — Especificar manifesto
  - Definir schemas versionados para movement/instruction/media/program
  - Representar ausência, incompatibilidade de variante e revisão pendente
- V1-004-T02 — Criar regras de publicação
  - Definir allowlist e motivos de bloqueio por operação
  - Distinguir referência externa, incorporação e redistribuição comercial

Validação: Validar manifesto com 11 componentes N15 e pacote ES2019 separados; Rejeitar componente sem proveniência ou unidade válida

Entregas: content/schemas/editorial-v1.schema.json; content/manifests/pilot-rights-matrix.json; content/manifests/pilot-prepared.json; tools/conteudo_editorial.py; tools/preparar_conteudo_local.py; docs/conteudo/preparacao-local-2026-10-21.md

Handoff: Registrar arquivos/contratos alterados, comandos e resultados reais, pendências e próxima história desbloqueada em docs/execucao/v1/diario.md; atualizar este JSON, regenerar backlog e conferir mapas versionados. Concluir somente com os critérios e evidências desta história.

### V1-005 — Revisar o lote real para o uso do piloto

**done · V1 · L**

Como usuário, quero ver apenas o uso que o material realmente permite.

Dependências: V1-004

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md; docs/conteudo/README.md; docs/arquitetura/dominio-e-banco.md; content/schemas/editorial-v1.schema.json; content/manifests/pilot-prepared.json; content/manifests/pilot-rights-matrix.json; content/manifests/pilot-review-queue.json; docs/conteudo/preparacao-local-2026-10-21.md; content/manifests/pilot-review-decisions.json; content/manifests/pilot-approved.json; docs/conteudo/revisao-consulta-2026-10-21.md; content/manifests/pilot-dispositions.json

Critérios de aceite:

- Cada item tem evidência de direitos e fidelidade do que será exibido, sem copiar PDF/foto indevidamente
- Revisão editorial e de segurança tem responsável real e resultado, ou item continua bloqueado
- Apoio profissional exigido só habilita execução se de fato existir; sem parceiro presumido

Tarefas e subtarefas:

- V1-005-T01 — Conferir o lote
  - Reutilizar fonte, autoria e recibo guardado; consultar rede só com pista nova
  - Verificar localização e material específico, não só licença do site
- V1-005-T02 — Classificar uso
  - Registrar consulta ou prática permitida e revisor
  - Retirar do manifesto de publicação itens sem cobertura; manter lacuna visível

Validação: Revisão linha a linha da allowlist; Tentar publicar item bloqueado e comprovar rejeição

Entregas: content/manifests/pilot-approved.json (somente metadados de consulta); content/manifests/pilot-dispositions.json; docs/execucao/v1/etapa-01-fechamento.md

Handoff: Registrar arquivos/contratos alterados, comandos e resultados reais, pendências e próxima história desbloqueada em docs/execucao/v1/diario.md; atualizar este JSON, regenerar backlog e conferir mapas versionados. Concluir somente com os critérios e evidências desta história.

### V1-006 — Importar conteúdo de forma idempotente e auditável

**done · V1 · M**

Como operador, quero carregar o lote aprovado no PostgreSQL sem pesquisa em runtime nem duplicações.

Dependências: V1-005, V1-010

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md; docs/conteudo/README.md; docs/arquitetura/dominio-e-banco.md

Critérios de aceite:

- Dry run informa contagens/erros e não escreve; importação usa versão/hash e transação
- Reimportação não duplica, versão publicada permanece imutável e retirada deixa motivo
- Zero seed de usuários, progresso, plano IA ou instrução completada artificialmente

Tarefas e subtarefas:

- V1-006-T01 — Construir importador Go
  - Ler apenas manifesto revisado e arquivos autorizados
  - Validar referências, hash, versão, unidade e direitos antes da transação
- V1-006-T02 — Ensaiar atualização
  - Carregar lote real em DB isolado e comparar IDs/contagens
  - Reimportar, criar versão e retirar item preservando referências históricas

Validação: Integração PostgreSQL com manifesto real permitido; Dry run inválido não escreve e reimportação é estável

Entregas: cmd/import-content; Relatório de importação e rollback editorial

Handoff: Registrar arquivos/contratos alterados, comandos e resultados reais, pendências e próxima história desbloqueada em docs/execucao/v1/diario.md; atualizar este JSON, regenerar backlog e conferir mapas versionados. Concluir somente com os critérios e evidências desta história.

## EP03 — Fundação Go, contratos e banco

Uma API pequena com configurações, migrations e domínio próprios; preservar as boas invariantes do legado.

### V1-007 — Criar o esqueleto do monólito modular Go

**done · V1 · M**

Como desenvolvedor, quero iniciar API e testes de forma previsível com módulos explícitos.

Dependências: V1-002

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md; docs/arquitetura/arquitetura-alvo.md; docs/arquitetura/contratos-v1.md; docs/arquitetura/dominio-e-banco.md

Critérios de aceite:

- services/api contém cmd/api e internal/{auth,catalog,activity,nutrition,platform}
- Configuração por ambiente validada sem segredo em logs; sem chave IA obrigatória
- Servidor tem timeout, limite de corpo, request ID, shutdown e health/readiness com semântica diferente

Tarefas e subtarefas:

- V1-007-T01 — Inicializar módulo
  - Usar net/http e escolher somente dependências justificadas (pgx e biblioteca de migrations)
  - Criar config tipada, roteador versionado e erros comuns
- V1-007-T02 — Operar localmente
  - Criar .env.example sem valores reais e comando único de desenvolvimento
  - Adicionar health live e ready dependente de banco com timeout

Validação: go test ./...; go vet ./... e processo inicia/finaliza sem conexão vazada

Entregas: services/api/go.mod; Servidor local e instruções reproduzíveis

Handoff: Registrar arquivos/contratos alterados, comandos e resultados reais, pendências e próxima história desbloqueada em docs/execucao/v1/diario.md; atualizar este JSON, regenerar backlog e conferir mapas versionados. Concluir somente com os critérios e evidências desta história.

### V1-008 — Gerar Swagger dos comentários e DTOs Go antes do cliente

**done · V1 · M**

Como integrador, quero comentar os handlers/tipos Go e obter Swagger atualizado automaticamente no desenvolvimento e conferido na CI, sem YAML manual concorrente.

Dependências: V1-004, V1-007

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md; docs/arquitetura/arquitetura-alvo.md; docs/arquitetura/contratos-v1.md; docs/arquitetura/dominio-e-banco.md; docs/arquitetura/swagger-go.md; docs/arquitetura/camadas-go.md

Critérios de aceite:

- Handlers, DTOs e comentários realizam os contratos revisados; Swaggo fixado gera JSON/YAML e integração Go sem edição manual desses derivados
- Versão inicial proposta v1.16.6 gera Swagger2.0; compatibilidade real com cliente Dart deve ser testada antes da adoção ou de mudança para OpenAPI3
- Recarga de desenvolvimento executa geração → compilação → restart e ignora gerados para evitar loop; CI falha em divergência de spec/código
- Anotação @Security não substitui autenticação/autorização; null, unidades, cursor, datas/fuso e idempotência são coerentes com os testes

Tarefas e subtarefas:

- V1-008-T01 — Documentar uma primeira rota real
  - Definir DTOs e comentários @Router/@Param/@Success/@Failure sobre o contrato revisado
  - Conferir registro net/http, erros, política de acesso e serialização com testes reais
- V1-008-T02 — Concretizar geração e recarga
  - Validar Swaggo v1.16.6 e tools/gerar_swagger.py com o serviço presente; importar swaggerdocs e integrar UI net/http
  - Configurar watcher para gerar/compilar/reiniciar sem observar gerados; atualizar CI Go com ferramenta fixada
- V1-008-T03 — Conferir consumidores e segurança
  - Comparar código, registro, spec e respostas dos handlers; testar cliente Dart compatível
  - Expor UI por ambiente com autenticação/configuração deliberadas, sem credenciais nos exemplos

Validação: Gerar duas vezes e comparar os derivados; mudar comentário e conferir atualização; Provocar divergência de contrato e confirmar falha na CI; Testes de resposta, autorização e cliente contra Swagger gerado, sem spec fictícia com Go ausente

Entregas: services/api/internal/swaggerdocs/docs.go (gerado); contracts/generated/swagger-v1.json e swagger-v1.yaml (gerados); Watcher de desenvolvimento e validação de contrato na CI; Política de compatibilidade

Handoff: Registrar arquivos/contratos alterados, comandos e resultados reais, pendências e próxima história desbloqueada em docs/execucao/v1/diario.md; atualizar este JSON, regenerar backlog e conferir mapas versionados. Concluir somente com os critérios e evidências desta história.

### V1-009 — Modelar conteúdo versionado, adesão e ocorrências

**done · V1 · M**

Como usuário, quero repetir uma atividade em outra data sem perder histórico ou mudar a fonte original.

Dependências: V1-004, V1-007

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md; docs/arquitetura/arquitetura-alvo.md; docs/arquitetura/contratos-v1.md; docs/arquitetura/dominio-e-banco.md

Critérios de aceite:

- Programa/versão/sessão prescrita separados de enrollment/ocorrência/registro real
- Movimentos e instruções têm proveniência própria; cuidador praticante separado de pessoa assistida
- Sessão usa ocorrência e estado explícito; fonte alterada não reescreve histórico

Tarefas e subtarefas:

- V1-009-T01 — Desenhar modelo
  - Revisar entidades e relações de dominio-e-banco.md
  - Definir timezone, unidades, estados, exclusão e retenção
- V1-009-T02 — Definir invariantes
  - Unicidade de idempotência por usuário/operação e sessão aberta por ocorrência
  - Planejar índices por consulta; não restaurar índice de um refresh por usuário indiscriminadamente

Validação: Revisão ER/contratos com N15 e prática por tempo; Casos semana repetida, plano inativo e autoria preservada

Entregas: Modelo lógico revisado; Decisão de invariantes e consultas

Handoff: Registrar arquivos/contratos alterados, comandos e resultados reais, pendências e próxima história desbloqueada em docs/execucao/v1/diario.md; atualizar este JSON, regenerar backlog e conferir mapas versionados. Concluir somente com os critérios e evidências desta história.

### V1-010 — Criar migrations e testar backup/restauração

**done · V1 · L**

Como operador, quero evoluir o banco sem perder pesquisa ou registros pessoais.

Dependências: V1-009

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md; docs/arquitetura/arquitetura-alvo.md; docs/arquitetura/contratos-v1.md; docs/arquitetura/dominio-e-banco.md

Critérios de aceite:

- Banco isolado sobe do zero por migrations Go; Prisma não migra o mesmo schema simultaneamente
- Backup restaurado em outra base é conferido por contagens e referências
- Banco legado não é presumido vazio: se migração de seus dados estiver no recorte, inventariar com acesso autorizado; na fundação isolada registrar o inventário como gate obrigatório de uma migração futura, sem inventar contagens

Tarefas e subtarefas:

- V1-010-T01 — Preparar base isolada
  - Escolher versão Postgres suportada na execução e porta sem conflito
  - Aplicar constraints, índices e usuário runtime de menor privilégio
- V1-010-T02 — Ensaiar restauração e evolução
  - Criar backup antes de mudança e restaurar em base separada
  - Testar migration forward e estratégia de recuperação sem down destrutivo automático

Validação: Migrations do zero e upgrade em DB de teste; Restore conferido; nunca docker compose down -v como rotina

Entregas: services/api/migrations; Runbook de backup/restore com resultado

Handoff: Registrar arquivos/contratos alterados, comandos e resultados reais, pendências e próxima história desbloqueada em docs/execucao/v1/diario.md; atualizar este JSON, regenerar backlog e conferir mapas versionados. Concluir somente com os critérios e evidências desta história.

## EP04 — Identidade, privacidade e acesso

Autenticação real, sessões revogáveis e isolamento de dados por usuário, inclusive sob concorrência.

### V1-011 — Autenticar Google no novo serviço

**done · V1 · M**

Como testador, quero entrar com minha conta real e usar a mesma identidade nas duas plataformas.

Dependências: V1-008, V1-010

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md; docs/arquitetura/seguranca-operacao.md; docs/arquitetura/contratos-v1.md

Critérios de aceite:

- ID token validado por assinatura/iss/aud/exp e identidade vinculada a issuer+sub
- E-mail não é chave única de associação automática entre provedores
- Android debug/release têm OAuth correto; IDs públicos separados de segredos; HTTPS fora do desenvolvimento

Tarefas e subtarefas:

- V1-011-T01 — Implementar troca
  - Preservar validações úteis do legado e testar audience incorreta
  - Criar usuário apenas a partir de autenticação real consentida
- V1-011-T02 — Configurar ambientes
  - Documentar fingerprint do certificado debug/release e client ID de servidor
  - Preparar configuração iOS futura sem declarar teste feito

Validação: Integração com login real no Android; Testes de token inválido/expirado e identidade duplicada

Entregas: Auth Go e contrato de sessão; Guia OAuth por ambiente

Handoff: 23/10: critérios do checkpoint local concluídos com contaGoogle real consentida, sessão/refresh/logout/reentrada e privacidade/exclusão autorizada. OAuthdebug/release conferidos; HTTPS fora do desenvolvimento permanece obrigatório, sem exposição externa. Hospedagem agora foi recusada pelo autor e não bloqueia teste local. Ver auth-local-fechamento.md; gates de distribuição/HTTPSstaging/iOS permanecem nas histórias próprias.

### V1-012 — Rotacionar e revogar refresh tokens

**done · V1 · L**

Como usuário, quero continuar conectado e encerrar acesso de forma confiável.

Dependências: V1-011

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md; docs/arquitetura/seguranca-operacao.md; docs/arquitetura/contratos-v1.md

Critérios de aceite:

- Refresh hash armazenado, rotação atômica single use e detecção de reuso por família
- Logout revoga sessão no servidor; outro dispositivo não é revogado sem intenção
- Flutter serializa refresh concorrente; rede indisponível não apaga sessão válida

Tarefas e subtarefas:

- V1-012-T01 — Implementar ciclo servidor
  - Definir família de sessão, expiração, revogação e transação concorrente
  - Testar dois refresh simultâneos e resposta sem token nos logs
- V1-012-T02 — Integrar cliente
  - Guardar tokens em secure storage; retry único após 401 e refresh coordenado
  - Separar 401 confirmado de timeout/offline e revogar no logout

Validação: Teste PostgreSQL concorrente; Login, expiração, refresh e logout reais em emulador

Entregas: Ciclo de sessão Go/Flutter; Política de reuso e dispositivos

Handoff: 23/10: critérios do checkpoint local concluídos com contaGoogle real consentida, sessão/refresh/logout/reentrada e privacidade/exclusão autorizada. OAuthdebug/release conferidos; HTTPS fora do desenvolvimento permanece obrigatório, sem exposição externa. Hospedagem agora foi recusada pelo autor e não bloqueia teste local. Ver auth-local-fechamento.md; gates de distribuição/HTTPSstaging/iOS permanecem nas histórias próprias.

### V1-013 — Aplicar autorização, limites e ciclo dos dados

**done · V1 · L**

Como titular, quero que só eu acesse meus registros e que exclusão seja verificável.

Dependências: V1-011, V1-009

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md; docs/arquitetura/seguranca-operacao.md; docs/arquitetura/contratos-v1.md; docs/execucao/v1/privacidade-013.md

Critérios de aceite:

- Todas as consultas/mutações privadas filtram ownership, inclusive IDs trocados
- Proxy confiável explicitamente configurado; rate limit não confia em X-Forwarded-For arbitrário
- Exportação/exclusão e retenção cobrem DB, fotos futuras, caches e backups com limites explicados

Tarefas e subtarefas:

- V1-013-T01 — Cobrir autorização
  - Criar matriz rota × usuário/terceiro/anônimo
  - Manter uso próprio e acompanhamento de terceiro como permissões distintas
- V1-013-T02 — Controlar dados e recursos
  - Definir limites de corpo/paginação/tempo e regras proxy
  - Implementar minimização, exportação e exclusão confirmada; registrar política de backups

Validação: Testes BOLA em todos os recursos privados; Teste de spoof de forwarded header, corpo grande e exclusão de conta de teste

Entregas: Matriz de acesso; Política de privacidade do piloto e operações de dados

Handoff: 23/10: critérios do checkpoint local concluídos com contaGoogle real consentida, sessão/refresh/logout/reentrada e privacidade/exclusão autorizada. OAuthdebug/release conferidos; HTTPS fora do desenvolvimento permanece obrigatório, sem exposição externa. Hospedagem agora foi recusada pelo autor e não bloqueia teste local. Ver auth-local-fechamento.md; gates de distribuição/HTTPSstaging/iOS permanecem nas histórias próprias.

### V1-049 — Autorizar exclusão própria e exceção master auditada

**todo · V1 · L**

Como titular, quero que somente minha conta possa excluir meus dados particulares, com exceção controlada e auditada do administrador master do projeto.

Dependências: V1-012, V1-013, V1-017, V1-020, V1-021, V1-042, V1-045

Entradas: docs/execucao/v1/decisoes-piloto.md; docs/execucao/v1/trilha-implementacao.md; docs/execucao/v1/escopo.md; docs/execucao/v1/matriz-cenarios.md; docs/arquitetura/seguranca-operacao.md; docs/arquitetura/dominio-e-banco.md

Critérios de aceite:

- Q6:usuário comum exclui somente seus próprios treinos/registros/alimentos particulares/refeições/fotos; trocar ID ou usar fila/chamada direta não concede acesso alheio
- Exceção master é explícita, revogável e mantida no servidor para identidade autenticada estável verificada; default sem privilégio, sem inferência por e-mail/GitHub, claim do cliente ou segredo no APK
- Provisionamento da conta master real exige verificação antes da ativação; não promover primeiro usuário ou conta atual por suposição
- Exclusão master usa confirmação reforçada, recurso/titular exatos e motivo; auditoria mínima de ator/alvo/resultado sem tokens, fotos, corpos privados ou dados clínicos
- Permissão de exclusão não implica leitura/edição/impersonação irrestritas ou promoção de outras contas; dados editoriais compartilhados e retirada lógica conservam seu contrato
- RegrasQ4 de arquivo/miniatura/cache/fila e backups se aplicam à exclusão autorizada; reenvio não recria dados e falha parcial de limpeza é recuperável
- Testar proprietário, terceiro, anônimo, master válido/revogado, privilégio forjado, confirmação inválida, repetição e corrida com upload/reenvio em base isolada; aceite privilegiado real só com identidade/ação autorizadas

Tarefas e subtarefas:

- V1-049-T01 — Modelar permissão e provisionamento controlado
  - Definir matriz de ações por recurso e limites do master sem bypass geral de ownership
  - Definir identidade estável, concessão/revogação no servidor e fluxo de confirmação/auditoria
  - Planejar migration e ciclo de privacidade do registro administrativo sem segredo/role no cliente
- V1-049-T02 — Integrar exclusão autorizada por recurso
  - Preservar operações do titular e adicionar a exceção por caso de uso com verificação no servidor
  - Integrar treinos/alimentos/refeições/fotos e limpeza privada sem apagar catálogo compartilhado
  - Expor controles administrativos somente após permissão confirmada; ausência de permissão não revela dados privados
- V1-049-T03 — Validar negativos e aceite controlado
  - Ensaiar acesso alheio, papel/ID forjado, revogação, confirmação inválida, auditoria e idempotência
  - Cobrir processo/fila/upload concorrentes sem reaparecimento de dados excluídos
  - Vincular identidade master e executar aceite real somente quando o fluxo estiver pronto, sem apagar histórico por inferência

Validação: Matriz de autorização por recurso com negativos automatizados; Integração e auditoria em banco/arquivos isolados; Aceite privilegiado real autorizado, com vínculo da identidade comprovado

Entregas: Permissão master controlada e revogável; Exclusão própria/master por recurso com auditoria; Recibo de isolamento, negativos, limpeza e aceite

Handoff: 25/10:Q6 definiu exclusão por quem incluiu os dados ou pelo master, o autor do projeto. Backend atual só tem ownership por titular; nenhuma permissão master foi encontrada ou provisionada. Regra registrada sem autorizar exclusão real agora. Identidade master ainda exige verificação; avançar apenas no trabalho independente.

## EP05 — Biblioteca humana e API de catálogo

Consumir conteúdo pesquisado com origem e disponibilidade reais, sem gerar programas de fallback.

### V1-014 — Servir catálogo, versão e requisitos de uso

**done · V1 · M**

Como praticante, quero comparar opções reais por público, local e apoio.

Dependências: V1-006, V1-008

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md; docs/conteudo/README.md; docs/arquitetura/dominio-e-banco.md

Critérios de aceite:

- GET catalog/programs e detalhe retornam somente conteúdo permitido ao modo de consulta/prática
- Filtros representam ambiente, modalidade, público e equipamento reais; cursor estável
- Fonte, contribuição, versão, direitos, unidades e razões de bloqueio chegam ao Flutter

Tarefas e subtarefas:

- V1-014-T01 — Implementar leitura
  - Consultar tabelas versionadas com projeção explícita
  - Expor paginação e ETag por versão sem baixar vídeo nem consultar fornecedor a cada toque
- V1-014-T02 — Cobrir falta de conteúdo
  - Retornar indisponibilidade e alternativas pesquisadas sem completar texto/dose
  - Distinguir peça modular de programa completo no contrato

Validação: Contrato e DB com lote real; Filtro e item retirado não vazam conteúdo não autorizado

Entregas: Handlers e queries de catálogo; Respostas verificadas do lote

Handoff: 22/10: leitura Go/Flutter de catálogo concluída com73metadados reais e0programas/prática; cinco rotas públicas, filtros/cursor/versões/ETag/retirada, atribuição e requisitos ausentes explícitos. Ver catalogo-consulta.md e catalog-read-verification.json. Não encerra016/022 nem loginGoogle.

### V1-047 — Persistir configuração completa antes da seleção de treino

**done · V1 · L**

Como praticante, quero concluir e revisar minha configuração antes de procurar um treino compatível e recuperar esse contexto pela minha conta.

Dependências: V1-008, V1-012, V1-013, V1-021, V1-048

Entradas: docs/execucao/v1/decisoes-piloto.md; docs/execucao/v1/trilha-implementacao.md; docs/execucao/v1/escopo.md; docs/execucao/v1/frontend-fidelidade-figma.md; docs/arquitetura/dominio-e-banco.md; docs/arquitetura/contratos-v1.md

Critérios de aceite:

- Configuração completa e revisada antecede busca/seleção de treino compatível e confirmação da composição; consulta pública de referências, alimentação e privacidade conservam seu recorte
- Matriz por campo define finalidade, origem, obrigatório/condicional/opcional, valores/unidades, validação, persistência e uso nas regras; não herdar peso/altura/idade/gordura obrigatórios ou padrões fictícios do onboarding legado
- Ambiente/recursos, disponibilidade e contexto de pausa do próprio cuidador respeitam os dados declarados; preferências não viram dose, progressão ou adequação clínica inventadas
- Configuração privada pode ser salva, recuperada e alterada por sua conta com versão/concorrência e erros de campo explícitos; mudança de conta ou resposta tardia não mistura dados
- Atualizar contexto não reescreve sessões/versões históricas; novas escolhas são validadas pelo backend contra configuração e requisitos humanos atuais
- Go/SQL/Flutter separados por responsabilidade, DTOs e Swagger coerentes, autorização por titular e testes de persistência/isolamento; completar formulário não libera prática bloqueada
- Fluxo legado de geração IA/manual-generator permanece fora da composição ativa; nenhum formulário simula salvamento ou elegibilidade sem API/regra implementadas
- Q5:configuração em etapas curtas por assunto, com progresso real, retorno/correção sem perda de respostas e revisão final antes de confirmar; preservar acessibilidade e tratar saída/falha/descarte sem falso salvamento

Tarefas e subtarefas:

- V1-047-T01 — Detalhar campos e persistência privada
  - Reutilizar categorias Q3, requisitos das fontes e referências visuais obtidas; não repetir chamadas Figma limitadas
  - Fechar matriz de campos por finalidade e distinguir contexto necessário de medida física opcional ou sem uso
  - Definir modelo/versionamento e migration forward sem reset, preservando dados e fluxo de privacidade
- V1-047-T02 — Implementar contrato e configuração revisável
  - Implementar casos de uso Go para salvar/ler/alterar configuração com titularidade e conflito de versão
  - Gerar Swagger por tipos/comentários e integrar repository/controller Flutter injetados
  - Concluir e revisar a configuração antes de abrir a seleção de treino; tratar vazio/erro/rede/retorno sem reativar geradores
  - Organizar etapas por assunto e revisão final com retorno ao campo; preservar respostas, foco/teclado e validação, usando localização048
- V1-047-T03 — Validar jornada e compatibilidade
  - Testar campos condicionais/desconhecidos, concorrência, conta trocada e respostas atrasadas
  - Conferir persistência/recuperação em base isolada e atualização sem alterar histórico anterior
  - Registrar aceite real do fluxo e limites editoriais; fixtures não comprovam treino liberado

Validação: Matriz de campos fundamentada e contratos/UI/SQL coerentes; Testes Go/SQL/Flutter de persistência, ownership, concorrência e estado; Aceite de configuração completa e revisão antes da seleção, com ausência de conteúdo honesta

Entregas: Configuração privada persistida e versionada; Contrato e fluxo Flutter completos para revisão; Recibo de campos, isolamento, atualização e aceite

Handoff: 27/10: V1-047 encerrada no recorte funcional local. O autor criou, revisou e confirmou a configuração real; o agente reabriu as quatro etapas e o resumo. Após autorização explícita, somente o horário inicial foi corrigido pela UI/API, gerando a revisão 2. Um novo controlador recuperou essa revisão após reabertura. Comparação SQL somente de leitura confirmou a preservação da revisão 1 e sua data, dos demais campos, da conta, do consumo e do catálogo. Sem terceira versão, novo login Google ou fixtures na conta. APK 22, API 0.7.0 e schema 12 mantidos. Clareza de fuso, hora e navegação permanece pendente na fonte frontend para depois dos testes; o fechamento funcional não aprova toda a usabilidade. Próxima V1-015 pelas dependências e com conteúdo humano como requisito. V1-045 segue doing: leitura e CreateMeal no domínio/aplicação; SQL, privacidade, HTTP e Flutter pendentes.

### V1-015 — Criar adesão sem geração de treino

**todo · V1 · M**

Como usuário, quero selecionar uma versão existente e uma agenda permitida pelo autor.

Dependências: V1-014, V1-013, V1-047

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md; docs/conteudo/README.md; docs/arquitetura/dominio-e-banco.md; docs/execucao/v1/trilha-implementacao.md

Critérios de aceite:

- Adesão aponta para versão imutável e valida os requisitos necessários
- Composição personalizada mantém autoria de componentes e perde rótulo de programa original se alterado
- Rotas IA/manual-generator não participam da V1 e Gemini deixa de ser requisito
- Q3:adesão/seleção exige configuração completa revisada; dias/horários e trocas compatíveis respeitam regras humanas sem reescrever ocorrências ou versões históricas

Tarefas e subtarefas:

- V1-015-T01 — Implementar adesão
  - Validar versão publicada, consentimentos e apoio exigido
  - Aceitar apenas opções de agenda previstas pela fonte, sem inventar progressão
- V1-015-T02 — Tratar troca e arquivamento
  - Preservar adesão e sessões antigas ao escolher outra versão
  - Retornar motivo concreto de incompatibilidade sem prescrição automática

Validação: Selecionar lote real no banco e consultar adesão; Rejeitar variante, público ou modo incompatível

Entregas: API de enrollments; Fluxo de seleção humano

Handoff: Registrar arquivos/contratos alterados, comandos e resultados reais, pendências e próxima história desbloqueada em docs/execucao/v1/diario.md; atualizar este JSON, regenerar backlog e conferir mapas versionados. Concluir somente com os critérios e evidências desta história. 24/10: auditoria do produto registrada em auditoria-produto-2026-10-24.md. Revisão estática/contagens e cobertura não encerram a história; ver lacunas e ordem pelas dependências. Sem compra/hospedagem ou dados fictícios. 25/10:Q3 aprovado; configuração047 antecede seleção/adesão. Trocas de exercícios são restritas a alternativas compatíveis e agenda deve respeitar a fonte. 28/10: após047 funcional, conferência local mostrou zero programas/guided_practice e importador restrito a movimentos/catalog_metadata. Adesão e agenda ainda não implementadas; sem conteúdo humano não há aceite real. Continuar045 independente sem converter metadados em prescrição.

### V1-016 — Expor instrução acessível e mídia com direitos

**todo · V1 · M**

Como usuário, quero aprender o material disponível e saber quem o escreveu.

Dependências: V1-014

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md; docs/conteudo/README.md; docs/arquitetura/dominio-e-banco.md; docs/execucao/v1/trilha-implementacao.md

Critérios de aceite:

- Texto fiel revisado, idioma, atribuição e versão aparecem juntos
- Mídia ausente fica indisponível; nenhuma foto/vídeo de placeholder ou extração BeFit
- Se existir mídia autorizada, entrega não expõe bucket nem exige download irrestrito
- Triagem005concluida nao libera os439ativos excluidos: praticas requerem evidencia especifica/profissional e apoio conforme a fonte; nao fechar aceite integrado somente com catalogo de referencia

Tarefas e subtarefas:

- V1-016-T01 — Servir material permitido
  - Separar referência externa de ativo redistribuível
  - Expor autoria, legenda/transcrição quando autorizada e texto alternativo
- V1-016-T02 — Controlar retirada
  - Revogar entrega de ativo sem apagar proveniência de sessões passadas
  - Aplicar cache versionado e custo/quota de mídia se necessária

Validação: Inspeção visual e acessibilidade do material real; Link indisponível, versão retirada e ausência de vídeo sem fallback fictício

Entregas: Contrato de instruction/media; Lista de ativos efetivamente liberados

Handoff: 22/10: V1-014 concluída para metadados; nenhuma instrução/mídia/prática liberada na triagem. Preservar439exclusões; esta história exige material efetivamente autorizado e revisado, sem conteúdo fabricado. Não encerrar por mostrar atribuição ou ausência de mídia. 24/10: auditoria do produto registrada em auditoria-produto-2026-10-24.md. Revisão estática/contagens e cobertura não encerram a história; ver lacunas e ordem pelas dependências. Sem compra/hospedagem ou dados fictícios.

### V1-044 — Compor treino com regras humanas revisadas

**todo · V1 · L**

Como praticante, inclusive cuidador nas pausas do próprio trabalho, quero escolher um programa compatível ou usar uma composição permitida conforme meu contexto, sem prescrição inventada.

Dependências: V1-015, V1-016, V1-021

Entradas: docs/execucao/v1/decisoes-piloto.md; docs/execucao/v1/trilha-implementacao.md; docs/execucao/v1/escopo.md; docs/arquitetura/dominio-e-banco.md; docs/arquitetura/contratos-v1.md; docs/conteudo/evidencias-para-integracao.md

Critérios de aceite:

- Dois caminhos distinguíveis: escolher versão de programa humano compatível e compor coleção com regras humanas revisadas; não rotular composição alterada como programa original
- Contexto/opções editáveis definidos antes do modelo e persistência; preservar autoria, versão, instrução, dose, direitos e apoio de cada componente
- Combinação incompatível ou sem regra/material aprovado retorna motivo e bloqueio; nenhuma série, repetição, frequência ou adequação criada pela IA
- Cuidador é o próprio praticante durante pausas de trabalho; não exige cadastro ou dados da pessoa assistida e não concede acesso a outra conta
- Composição confirmada gera versão rastreável e integra adesão/agenda/execução sem reescrever sessões históricas
- Q3:usuário pode trocar exercícios compatíveis e ajustar dias/horários antes de confirmar; explicar incompatibilidade e manter dose/instrução/direitos da fonte, sem ajuste livre inventado

Tarefas e subtarefas:

- V1-044-T01 — Definir contexto e regras permitidas
  - Registrar escolhas do autor sobre entradas e opções alteráveis
  - Reutilizar dossiês/evidências existentes e separar regra aprovada de material indisponível
  - Especificar incompatibilidades e semântica de composição versus programa original
- V1-044-T02 — Implementar contrato, persistência e jornada
  - Modelar versão/atribuição dos componentes e casos de uso com interfaces pequenas
  - Integrar escolha/composição no Flutter sem geradores legados
  - Vincular versão confirmada à adesão e agenda permitidas
- V1-044-T03 — Validar fronteiras e aceite
  - Testar regras, ownership, concorrência e preservação de histórico em banco descartável
  - Executar um caso humano permitido e outro bloqueado sem conteúdo fictício no runtime

Validação: Contrato HTTP/Swagger e integração SQL/Flutter consistentes; Duas jornadas reais de seleção/composição com material aprovado; fixtures só comprovam regras técnicas

Entregas: Contrato e fluxo de composição controlada; Versão persistida com proveniência e regra humana; Recibo de casos permitidos/bloqueados

Handoff: 24/10:criada após respostaQ1 explícita 'Ter os dois caminhos'. Não equivale à expansão ampla da040 nem libera prática pela existência de metadados. Nenhuma implementação concluída; campos/regras ainda dependem de decisões e conteúdo aprovado. 25/10:Q3 definiu configuração completa047 antes da busca/seleção, trocas compatíveis e agenda editável; requisitos/valores de campos e regras de troca ainda a detalhar.

## EP06 — Atividade e alimentação registradas de verdade

Persistir ações reais, unidades corretas e histórico sem criar desempenho, dieta ou medição fictícios.

### V1-017 — Executar ocorrências idempotentes de atividade

**doing · V1 · L**

Como usuário, quero iniciar e terminar uma sessão uma vez, mesmo com reenvio da rede.

Dependências: V1-015, V1-012

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md; docs/arquitetura/contratos-v1.md; docs/arquitetura/fluxos.md; docs/execucao/v1/trilha-implementacao.md; docs/execucao/v1/execucao-treino-017.md

Critérios de aceite:

- Planejado, iniciado, pausado, parcial, concluído, não feito e descanso têm semântica explícita
- Idempotency-Key e constraints evitam duas sessões para a mesma ocorrência
- Conclusão de uma semana não bloqueia outra; duração observada separada da dose prescrita
- Q3:interromper oferece retomar ou encerrar parcial; saída de tela, relógio decorrido ou término do processo não concluem sessão nem geram eventos/medidas fictícios

Tarefas e subtarefas:

- V1-017-T01 — Implementar máquina de estados
  - Validar transições, timestamps UTC e data no fuso escolhido
  - Registrar exercício/tempo/repetições reais sem tratar prescrição como realizado
- V1-017-T02 — Testar concorrência
  - Repetir POST com mesma chave e payload diferente
  - Testar corrida, pausa, falha de rede e retomada

Validação: Integração PostgreSQL concorrente; Sessões reais em duas datas e estado parcial preservado

Entregas: API sessions e session-events; Invariantes documentadas e testes

Handoff: Registrar arquivos/contratos alterados, comandos e resultados reais, pendências e próxima história desbloqueada em docs/execucao/v1/diario.md; atualizar este JSON, regenerar backlog e conferir mapas versionados. Concluir somente com os critérios e evidências desta história. 24/10: auditoria do produto registrada em auditoria-produto-2026-10-24.md. Revisão estática/contagens e cobertura não encerram a história; ver lacunas e ordem pelas dependências. Sem compra/hospedagem ou dados fictícios. 25/10:Q3 exige recuperação do estado real ou encerramento parcial explícito; Q4 aprovou alimentação/andamento offline, com durabilidade e sincronização na026. 16/11: agregado puro de execução e contrato/projeção Flutter implementados; ver execucao-treino-017.md. Testes em memória não concluem HTTP/SQL, idempotência durável, autorização, conteúdo ou jornada no APK. Segundo incremento16/11: persistência/eventos/replay durável e quatro rotas privadas, autenticação viva e testes SQL/HTTP em descartável; nenhuma migration/dado na base entregue. Flutter integrado à aba Atividade. Conteúdo e aceite real continuam abertos.

### V1-018 — Consultar histórico e resumo com origem das métricas

**todo · V1 · M**

Como usuário, quero saber o que registrei, sem números de demonstração.

Dependências: V1-017

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md; docs/arquitetura/contratos-v1.md; docs/arquitetura/fluxos.md; docs/execucao/v1/trilha-implementacao.md

Critérios de aceite:

- Home, histórico e estatísticas vêm de registros persistidos e respeitam fuso e autoria
- Sem dado mostra ausência, não valor medido zero; estimativas identificam fórmula/fonte
- Histórico não depende apenas do plano ativo e usa cursor/intervalo limitado

Tarefas e subtarefas:

- V1-018-T01 — Criar consultas
  - Definir resumo diário e tendência com datas/fusos
  - Projetar índices e paginação para não carregar todas as sessões
- V1-018-T02 — Garantir semântica
  - Separar estimado/medido/planejado e evitar dupla contagem
  - Testar atividade sem calorias e novo usuário sem histórico

Validação: Conferir resumo contra linhas reais do DB; Casos fronteira de dia, troca de plano e registro editado

Entregas: API summary/history; Dicionário de métricas

Handoff: Registrar arquivos/contratos alterados, comandos e resultados reais, pendências e próxima história desbloqueada em docs/execucao/v1/diario.md; atualizar este JSON, regenerar backlog e conferir mapas versionados. Concluir somente com os critérios e evidências desta história.

### V1-019 — Validar e importar o lote alimentar

**done · V1 · L**

Como usuário, quero procurar alimentos pesquisados com preparo e unidades corretos.

Dependências: V1-004, V1-010

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md; docs/arquitetura/contratos-v1.md; docs/arquitetura/fluxos.md; docs/execucao/v1/decisoes-piloto.md; content/manifests/pilot-prepared.json; docs/conteudo/preparacao-local-2026-10-21.md; docs/execucao/v1/alimentacao-preflight.md; content/manifests/food-review-decisions.json; docs/execucao/v1/alimentacao-importacao.md

Critérios de aceite:

- Inventariar as fontes alimentares pesquisadas e importar todo o conteúdo utilizável/permitido em lotes técnicos versionados; reportar cobertura, duplicados, rejeições e pendências, sem limitar a base a uma amostra arbitrária
- Alimento/preparo, base 100g/100ml, porção e nutrientes ausentes mantidos distintos
- Não gerar receita, alergênico seguro, dieta ou medida caseira sem origem

Tarefas e subtarefas:

- V1-019-T01 — Selecionar e revisar fonte
  - Conferir catálogos N de alimentação e termos por dataset
  - Conferir cobertura e direitos por dataset/versão; preservar pendências sem presumir licença igual para todos os itens
- V1-019-T02 — Importar versão
  - Validar nutrientes/unidades e identificador de origem
  - Criar importador idempotente e relatório sem payload de terceiro no Git sem licença
  - Contabilizar entrada, importação, duplicados, rejeições e pendências por motivo; permitir retomar lotes sem duplicação

Validação: Comparar amostra importada à fonte autorizada; Rejeitar mistura entre alimento cru/cozido e null=0

Entregas: Manifesto alimentar aprovado; Lote alimentar versionado no DB

Handoff: 22/10: lote autorizado deCiqual2025/CoFID2021 importado integralmente:6369registros(3484+2885),2identidadesconflitantes excluídas e3basesdesconhecidas preservadas. Revisão porfonte/operação e importadorGo idempotente, migration00005aditiva, runtimeeditorialsomenteleitura; reimport0/6369, restore de backup novo conferiu todas as tabelas. Ver alimentacao-importacao.md, food-import-verification.json e manifestofood-approved.json. Outras20famílias mantêm gates próprios; APIbusca/consumo/Flutter não entregues.

### V1-020 — Pesquisar e cadastrar alimento próprio e registrar consumo

**done · V1 · L**

Como usuário, quero registrar uma quantidade real e consultar o que consumi.

Dependências: V1-019, V1-013, V1-008

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md; docs/arquitetura/contratos-v1.md; docs/arquitetura/fluxos.md; docs/execucao/v1/decisoes-piloto.md; docs/execucao/v1/alimentacao-consulta.md

Critérios de aceite:

- Busca paginada de alimentos reais e POST de registro com quantidade, unidade, preparo e versão
- Nutrientes derivados usam base/fator declarado; quantidade não confirmada não vira medida
- Sem dietas prescritas, história pré-populada ou compensação automática de calorias do treino
- Cadastrar alimento próprio com titular, origem e versão distintos do catálogo editorial; aceitar ausências sem inventar nutrientes e sem tornar o cadastro público ou revisado por inferência

Tarefas e subtarefas:

- V1-020-T01 — Criar contratos e handlers
  - Implementar foods e food-entries com ownership e idempotência
  - Definir edição/exclusão sem perder rastreio da origem do cálculo
  - Definir POST de alimento próprio e consulta autorizada; separar cadastro do alimento de registro de consumo e preservar isolamento entre contas
- V1-020-T02 — Integrar totais
  - Somar apenas registros confirmados com regras de null
  - Testar divergência de porção e registro em outro fuso

Validação: Integração DB/API com alimento pesquisado; Conferir cálculo contra base conhecida e histórico vazio; Testar cadastro próprio com nutrientes ausentes, busca autorizada e isolamento de outro usuário, sem alterar a fonte pesquisada

Entregas: API nutrition v1; Registro de consumo real

Handoff: 23/10: API Go0.5.1/25operações, migration00008 e Flutter de alimentação entregues; cadastro próprio/ausências/ownership/idempotência/edição/exclusão/totais conferidos emSQL/HTTPdescartável comfontereal. Autor confirmou consumo real noapp e histórico persistido. Visual completo doFigma permanece pendente; prioridade mudou para frontend. Ver alimentacao-registro.md, nutrition-real-android-verification.json e frontend-fidelidade-figma.md.

### V1-042 — Reconhecer alimentos por foto com revisão e quantidade informada

**todo · V1 · L**

Como usuário, quero fotografar uma refeição, corrigir os alimentos identificados e informar quanto consumi antes do cálculo e da confirmação.

Dependências: V1-013, V1-020, V1-025, V1-045

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md; docs/execucao/v1/trilha-implementacao.md; docs/execucao/v1/decisoes-piloto.md; docs/arquitetura/contratos-v1.md; docs/execucao/v1/pesquisa-fotos-historico.md

Critérios de aceite:

- Foto gera candidatos editáveis; usuário pode corrigir/remover/adicionar itens e informa quantidade por alimento antes de confirmar consumo
- Quantidade, ingredientes ocultos, preparo e nutrientes não são inventados pela imagem; correspondência com alimento/base/versão precisa ser confirmada
- Falha/baixa confiança permite busca/cadastro manual; reanálise/cancelamento não grava consumo nem duplica confirmação
- Modelo/capacidade, licença, precisão, privacidade e custo medidos em prova delimitada antes de adoção; nenhuma contratação automática
- Fotos sincronizadas são recuperáveis pela mesma conta em outro aparelho, com cache local; titularidade, limites, retenção/exclusão e estado de envio explícitos; rascunho não enviado não tem recuperação prometida
- Histórico visual apresenta registros confirmados e estado de foto ausente/sincronização, sem apagar consumo quando imagem falta
- OCR/barcode, imagem de atividade e gesto continuam recortes distintos posteriores; observações nutricionais dependem de escopo/regras próprias e não inferem deficiência de registros incompletos
- Q4:excluir refeição inteira remove foto/miniaturas do armazenamento ativo e invalida acesso/cache; upload, resposta atrasada ou retentativa não recriam dados nem mantêm cópia acessível como revisão
- Cancelamento/exclusão antes do primeiro envio cancela criação/upload; exclusão confirmada é reconciliada nos outros aparelhos quando conectarem, com limites de backups/cópias exportadas explícitos

Tarefas e subtarefas:

- V1-042-T01 — Definir política de foto e prova delimitada
  - Reutilizar evidênciasN06/N39/N40 sem pesquisa ampla de fornecedor
  - Implementar recuperação privada das fotos pela conta com cache local, conformeQ2; definir autorização, limites e expurgo sem recurso cloud por inferência
  - Medir identificação com imagens autorizadas, correções e baixa confiança; dados pessoais não são dataset por padrão
- V1-042-T02 — Implementar análise e confirmação por item
  - Separar captura/anexo privado, inferência, candidatos e correspondência com base versionada
  - Permitir corrigir/remover/adicionar e digitar quantidade; manter desconhecidos e incompatibilidades de unidade
  - Calcular com regrasGo existentes e gravar somente após confirmação humana idempotente
- V1-042-T03 — Integrar histórico visual e ciclo privado
  - Vincular imagem e itens sem depender de caminho local do aparelho como identidade do registro
  - Exibir falha/ausência/pendência de foto com registro textual preservado
  - Validar acesso entre contas, edição/exclusão/retentativa e recuperação conforme política aprovada
  - Integrar exclusão coordenada de refeição/arquivo/miniatura/cache/fila; testar upload/resposta tardia, cancelamento antes do envio e falha retentável de limpeza sem restabelecer acesso

Validação: Ensaio com imagens autorizadas e resultado real editado; métricas de identificação e correções registradas; Integração de foto revisada→quantidade informada→cálculo/consumo→histórico, sem fixtures como aceite humano; Testes de baixa confiança, reanálise/duplo envio, dados desconhecidos, titularidade e recuperação/exclusão

Entregas: Fluxo real de reconhecimento/revisão/quantidade/confirmação; Política de armazenamento e histórico visual privado; Resultados da prova de identificação e testes do ciclo privado

Handoff: Q1 antecipou alimento por foto paraV1, com quantidade digitada e consumo somente após confirmação. Em25/10,Q2 confirmou duas visões(refeição/alimento) na045, histórico/análise/dicas juntos na046 e recuperação das fotos pela conta com cache no celular após comparação de quatro produtos. Detalhar limites/retenção/exclusão e comprovar recuperação real; nenhuma funcionalidade concluída nesta rodada. Sem hospedagem, serviço pago ou envio a terceiros por inferência. Barcode/OCR/imagens de atividade continuam posteriores. Q4:foto excluída com a refeição; registro offline sincronizado depois na026. Implementar ciclo privado sem recriar dados por upload/reenvio; política de backups mantém limites já documentados.

### V1-045 — Organizar registros por refeição e por alimento

**doing · V1 · L**

Como usuário, quero ver minha alimentação agrupada em refeições e também consultar os alimentos individualmente, mantendo os mesmos dados e cálculos.

Dependências: V1-020, V1-021

Entradas: docs/execucao/v1/decisoes-piloto.md; docs/execucao/v1/trilha-implementacao.md; docs/execucao/v1/pesquisa-fotos-historico.md; docs/execucao/v1/escopo.md; docs/arquitetura/dominio-e-banco.md; docs/arquitetura/contratos-v1.md

Critérios de aceite:

- Refeição contém itens com quantidades/unidades e versões próprias; visão por alimento usa os mesmos registros, sem duplicar consumo ou nutrientes
- Usuário pode consultar refeição e detalhe por alimento, corrigir/excluir item e obter resumos consistentes; ações por refeição têm semântica explícita
- Alimentos de uma foto podem ser revisados e vinculados à refeição; foto não é identidade nem prova de consumo confirmado
- Entrada antiga sem informação de refeição permanece preservada e identificável; não inventar agrupamento ou nome de refeição do passado
- Ownership, fuso/data, revisões, idempotência e cálculos/desconhecidos da020 são mantidos nos novos agrupamentos
- Q4:excluir refeição inteira remove seus itens do histórico ativo e exclui foto/miniaturas; ação em só um alimento preserva os demais itens, sem galeria de foto criada por inferência

Tarefas e subtarefas:

- V1-045-T01 — Modelar relação refeição e itens
  - Especificar identidade, horários, correção/exclusão e compatibilidade dos registros existentes
  - Criar migrations/contratos sem reset e manter fonte/versionamento/cálculo por item
- V1-045-T02 — Integrar duas visualizações
  - Construir resumo da refeição e acesso aos alimentos sobre o mesmo estado/repository
  - Preservar navegação/rascunhos/conta e mensagens de imagem ausente ou pendente sem apagar consumo
- V1-045-T03 — Validar consistência e privacidade
  - Testar item criado/corrigido/excluído, reenvio e leitura entre contas em base descartável
  - Conferir totais, unidades/métodos, ausência e o registro humano existente sem alterá-lo por inferência
  - Testar cancelamento/exclusão da refeição com operações pendentes e reenvios;042 implementa remoção de foto sem cópia ativa órfã

Validação: Integração Go/SQL/Flutter das duas visões sem dupla contagem; Compatibilidade de registros anteriores e titularidade verificadas

Entregas: Modelo e contrato de refeições/itens; Visões por refeição e por alimento; Recibo de integridade/compatibilidade

Handoff: 28/10: SQL/HTTP/Flutter, seleção particular e UI de metadados integrados; API0.8.0/34/schema13/30. APK25 instalado/hash após autor salvar/sair; refeição de teste/metadados recuperados e acesso direto à biblioteca/retorno conferidos sem escrita.248testes completos antes do refinamento/37dirigidos depois/análise limpa/591mensagens. Autor criou/reabriu1refeição como teste de navegação, não consumo real:2consumos totais(1real anterior+1teste),1conta/6369versões/2revisões047 preservados. Não excluir teste nem agrupar legado por inferência. Doing:aceite real/correção/exclusão,foto042/ciclo;outbox026 própria. Não repetir SQL/restore/Google sem mudança pertinente.

### V1-046 — Entregar histórico visual, análise nutricional e dicas revisadas

**todo · V1 · L**

Como usuário, quero acompanhar minhas refeições visualmente, analisar os nutrientes registrados e receber observações educativas revisadas na primeira versão.

Dependências: V1-045, V1-020, V1-021

Entradas: docs/execucao/v1/decisoes-piloto.md; docs/execucao/v1/trilha-implementacao.md; docs/execucao/v1/pesquisa-fotos-historico.md; docs/execucao/v1/escopo.md; docs/arquitetura/contratos-v1.md; docs/conteudo/evidencias-para-integracao.md

Critérios de aceite:

- Histórico visual por refeição/alimento, análise dos nutrientes registrados e dicas educativas revisadas integram a primeira versão desejada; não adiar silenciosamente análise/dicas após a clarificaçãoQ2
- Resumos indicam período/fuso, registros e dias com dados, quantidade medida/estimada, métodos e campos desconhecidos; ausência não é zero nem prova de que alimento/nutriente não foi consumido
- Agregação preserva base/unidade/versão e não soma métodos ou unidades incompatíveis; não duplicar itens ao alternar a visão
- Observações sobre variedade/repetição e nutrientes têm regra, fonte, versão e revisão humana, condição de aplicabilidade e explicação; sem conselho inventado por IA
- Não concluir deficiência, criar meta clínica, prescrever suplemento/dose ou tratar diário parcial como ingestão integral; quando dados/regra faltam mostrar a limitação
- Fotos/miniaturas respeitam política aprovada e titularidade; análise do registro continua disponível se uma imagem faltar
- Testar consistência, correção/exclusão, período/fuso, desconhecidos, dados insuficientes, acessibilidade e mensagens revisadas antes do aceite humano
- Q4:registros pendentes locais ficam identificados e separados dos subtotais/análises confirmados; reconciliação/correção/exclusão atualiza o resultado uma vez, sem contar duplicado

Tarefas e subtarefas:

- V1-046-T01 — Definir regras e conteúdo revisado
  - Reutilizar evidências existentes e separar estatística descritiva de orientação educativa
  - Definir períodos, cobertura, aplicabilidade e como comunicar ausência/estimativas; não escolher limiar clínico por suposição
  - Preparar conjunto mínimo de dicas com fonte/licença/versão/revisor e testes dos motivos de exibição
- V1-046-T02 — Implementar análise e apresentação
  - Criar agregação/contrato por período compatível com as regras da020
  - Construir histórico visual e análise legíveis com dicas explicáveis, preservando marca/Figma e as duas visões
  - Atualizar resultado quando registros forem corrigidos/excluídos; não usar imagem como fonte de nutrientes
- V1-046-T03 — Validar dados e aceite
  - Ensaiar dados parciais, referências sem nutrientes/base, conflitos de método/unidade e reenvios em base isolada
  - Conferir regras/fontes e realizar aceite real do conjunto sem fixtures apresentadas como histórico do usuário

Validação: Resultados conferidos contra consumos/versões e cálculos da API; Cenários negativos de diário incompleto/desconhecido e revisão das mensagens; Aceite conjunto de histórico/análise/dicas com dados reais autorizados

Entregas: Contrato e tela de análise/histórico; Regras e conteúdo educativo revisados; Recibo de cálculos, limites e aceite

Handoff: 25/10:autor esclareceu expressamente que quer histórico visual, análise nutricional e dicas revisadas juntos na primeira versão. Aprovou também recuperar fotos pela conta com cache no celular, sem hospedagem agora. Escopo aprovado, não implementação; detalhar ciclo privado e regras/fontes/revisão sem inferência clínica.

## EP07 — Flutter e experiência da V1

Evoluir a lib existente por feature, com contratos reais, estado consistente e suporte às duas plataformas.

### V1-021 — Organizar configuração, composição e estado

**done · V1 · L**

Como desenvolvedor, quero telas pequenas e dependências substituíveis sem reescrever a lib inteira.

Dependências: V1-008, V1-012

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md; docs/arquitetura/contratos-v1.md; docs/arquitetura/fluxos.md; docs/execucao/v1/frontend-fidelidade-figma.md; docs/execucao/v1/trilha-implementacao.md

Critérios de aceite:

- Feature-first preservado; UI usa controller/viewmodel e repository injetado
- Dio central com base URL por flavor/dart-define, timeouts e sessão coordenada
- Logging por allowlist remove tokens/dados físicos; domínio não importa widgets ou Dio

Tarefas e subtarefas:

- V1-021-T01 — Preparar núcleo
  - Separar config dev/staging e futura produção
  - Definir composition root simples e ViewModels com APIs Flutter existentes antes de nova lib
- V1-021-T02 — Migrar uma fatia
  - Converter auth/bootstrap e uma tela com loading/error/empty/data
  - Reutilizar bootstrap e preservar abas/rascunhos sem cache eterno

Validação: flutter analyze e testes de estados relevantes; Inspecionar logs de login real sem segredos e sem logout por timeout

Entregas: lib/core revisada; Padrão de feature exemplificado

Handoff: 25/10:fundação021encerrada no recorte previsto de composição/configuração e uma fatia migrada, sem rewrite da lib. Fábricas lazy na raiz; repository privado por conta; NutritionController separa consulta/paginação/busca da tela; mensagens fora do adaptador. APP_ENV development/staging/production eHTTPS fora do development/debug local.108testesFlutter/analyze0issues;14domínios sem Flutter/Dio. Evidências históricas de sessão/logs reais reutilizadas pois HTTP/auth não mudaram. APK0.3.0+13 e dados reais preservados. Próxima048 pelas dependências;025/026/047/049 e aceite integral continuam abertos.

### V1-022 — Implementar entrada e biblioteca com conteúdo real

**doing · V1 · L**

Como iniciante, quero escolher uma opção humana e entender por que ela está disponível.

Dependências: V1-014, V1-015, V1-021

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md; docs/arquitetura/contratos-v1.md; docs/arquitetura/fluxos.md; docs/execucao/v1/decisoes-piloto.md; docs/execucao/v1/trilha-implementacao.md

Critérios de aceite:

- Login → contexto mínimo → biblioteca → detalhe → adesão sem AI/manual generator
- Filtros casa/praça/academia e públicos preservam restrições; origem e versão legíveis
- Ausência, incompatibilidade, carregamento e erro usam dados reais e ação útil
- Detalhe mostra foto e vídeo autorizados quando existirem, apenas a mídia disponível nos demais casos e ausência explícita de mídia/instrução quando faltar; lacuna não exclui metadados permitidos nem libera prática automaticamente

Tarefas e subtarefas:

- V1-022-T01 — Desenhar a fatia com o material
  - Comparar Figma vigente com campos reais do contrato
  - Reutilizar componentes/tokens e justificar novos fluxos sem copiar BeFit
- V1-022-T02 — Implementar telas e navegação
  - Criar catálogo/detalhe/requisitos e vínculo real
  - Persistir seleção e tratar botão voltar, leitor de tela e texto ampliado
  - Representar os estados reais da matriz de cenários e registrar limitações para o APK de avaliação, sem aparentar funções ainda não implementadas

Validação: Teste widget de erro/vazio/seleção; Emulador com API/DB e manifesto real aprovado

Entregas: Telas library/detail/enrollment; Mapa de fluxo atualizado

Handoff: 24/10:biblioteca/entrada e visual possuem implementação parcial comprovada nos recibos. Adesão e treino permitido ainda faltam; não concluir pela consulta de metadados. Seguir trilha-implementacao.md e dependências, usando frontend-fidelidade-figma.md como fonte visual única; Figma com limiteStarter, sem contorno/compra. 29/10: pedido de interface limpa implementado e validado no APK26. Fontes/autoria/licenças/cálculos foram centralizados em Perfil > Fontes e transparência, com entrada pública por Privacidade. Nomes de apresentação vinculados à versão:73movimentos/31alimentos em quatro idiomas; não são publicações humanas de nomes revisados. Busca em português/espanhol com vocabulário limitado e atalhos. Dados originais preservados. Sem fechamento integral da jornada ou de toda a tradução alimentar; recibo frontend-content-cleanup-verification.json.

### V1-023 — Implementar sessão e recuperação de interrupção

**doing · V1 · L**

Como praticante, quero acompanhar o material e registrar o que fiz sem perder a sessão ao trocar de aba.

Dependências: V1-016, V1-017, V1-022

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md; docs/arquitetura/contratos-v1.md; docs/arquitetura/fluxos.md; docs/execucao/v1/trilha-implementacao.md

Critérios de aceite:

- Player/instrução usa modalidade/unidade real; prática bloqueada quando requisito não atendido
- Pausar/retomar/encerrar/parcial funcionam com estado persistido e idempotência
- Matar processo e reabrir recupera registro real; sem duração/reps fictícias
- Q3:ao retornar ao treino interrompido, mostrar o que foi registrado e oferecer retomar ou encerrar parcial; timer, dose prevista e realizado distintos, sem concluir automaticamente

Tarefas e subtarefas:

- V1-023-T01 — Criar controller de sessão
  - Carregar prescrição e execução separadas
  - Persistir ocorrência e chave de reenvio, sincronizar confirmação servidor
- V1-023-T02 — Construir experiência
  - Mostrar instrução, fonte, dose disponível e entrada do realizado
  - Implementar pausa, saída segura e retomada sem simular vídeo

Validação: Integração Android com reinício e duplo toque; Repetir em data futura sem bloqueio da sessão passada

Entregas: Fluxo de sessão real; Evidência de recuperação

Handoff: Registrar arquivos/contratos alterados, comandos e resultados reais, pendências e próxima história desbloqueada em docs/execucao/v1/diario.md; atualizar este JSON, regenerar backlog e conferir mapas versionados. Concluir somente com os critérios e evidências desta história. 25/10:retomada/parcial escolhidos noQ3; persistência de eventos e retentativa devem sobreviver ao processo sem duplicar execução. 16/11: controller e tela única reutilizável na aba Atividade, composição lazy por conta e API persistida; formulário de realizado vazio, estados/encerramento explícitos, reenvio incerto só em memória. Conteúdo/instrução/player e recuperação de intenção após matar processo ainda pendentes; sem aceite nativo.

### V1-024 — Implementar Hoje, histórico e perfil

**todo · V1 · L**

Como usuário, quero enxergar meus próprios registros e gerenciar minha conta.

Dependências: V1-018, V1-021, V1-013

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md; docs/arquitetura/contratos-v1.md; docs/arquitetura/fluxos.md; docs/execucao/v1/trilha-implementacao.md

Critérios de aceite:

- Abas mantêm estado e exibem resumo real sem nova busca redundante a cada toque
- Histórico lista versões/ocorrências antigas e ausência honesta; perfil permite campos opcionais
- Exportação, logout/revogação e exclusão têm confirmação e resultado verificável

Tarefas e subtarefas:

- V1-024-T01 — Migrar as abas existentes
  - Ligar ViewModels às APIs e paginação com cache limitado
  - Separar tendência calculada de medição e limpar cache ao trocar conta
- V1-024-T02 — Concluir perfil
  - Minimizar dados físicos e explicar finalidade
  - Implementar operações privadas e estados de erro sem mostrar dados de outro usuário

Validação: Emulador com duas contas reais de teste autorizadas ou contas isoladas de integração; Conferir resumo com DB e logout/exclusão

Entregas: Hoje/history/profile; Estado de conta e privacidade

Handoff: Registrar arquivos/contratos alterados, comandos e resultados reais, pendências e próxima história desbloqueada em docs/execucao/v1/diario.md; atualizar este JSON, regenerar backlog e conferir mapas versionados. Concluir somente com os critérios e evidências desta história.

### V1-025 — Implementar busca, cadastro próprio e registro alimentar no Flutter

**doing · V1 · L**

Como usuário, quero consumir o lote alimentar real em uma refeição registrada por mim.

Dependências: V1-020, V1-021, V1-048

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md; docs/arquitetura/contratos-v1.md; docs/arquitetura/fluxos.md; docs/execucao/v1/decisoes-piloto.md; docs/execucao/v1/alimentacao-consulta.md; docs/execucao/v1/trilha-implementacao.md

Critérios de aceite:

- Tela procura alimento/preparo, confirma quantidade e registra por API
- Total, base por100 e campos desconhecidos são claros; sem dieta ou foto reconhecida fictícia
- Integração visual com Hoje mantém alimentação distinta de gasto da atividade
- Busca usa base ampla pesquisada e oferece cadastro de alimento próprio com dados reais informados, origem visível e nutrientes desconhecidos preservados; cadastro manual complementa a base
- Q5:usar nome traduzido somente quando revisado, preservar original/idioma/fonte/versão no detalhe e fallback original; busca/nome não alteram identidade, preparo, base ou cálculo (048)

Tarefas e subtarefas:

- V1-025-T01 — Criar feature nutrition
  - Reusar cliente e estado, adicionar busca com debounce/cancelamento
  - Construir detalhe, unidade e confirmação sem inferir peso por fotografia
  - Criar formulário de alimento próprio conectado à API, distinguindo criação do alimento e lançamento de consumo; manter ausência e validação de unidade/base explícitas
- V1-025-T02 — Ligar histórico
  - Editar/excluir registro próprio e atualizar resumo
  - Oferecer vazio real quando lote/quantidade não disponível

Validação: Flutter analyze e widgets de unidades/ausência; Registro ponta a ponta com fonte alimentar real; Buscar item importado e cadastrar item próprio real; confirmar origem, persistência, ausência de nutrientes e privacidade entre contas

Entregas: Feature nutrition; Refeição persistida e exibida

Handoff: 24/10:consumo humano real preservado e fluxos alimentares refinados noAPK0.3.0+13. Cadastro próprio e demais jornadas exigem aceite humano; corrigir validação divergente, terminologia e recuperação conforme trilha-implementacao.md. Fonte visual única:frontend-fidelidade-figma.md. Não chamar fixtures de refeição/login real, nem marcar história encerrada pelo backend020 já entregue. 29/10: pedido de interface limpa implementado e validado no APK26. Fontes/autoria/licenças/cálculos foram centralizados em Perfil > Fontes e transparência, com entrada pública por Privacidade. Nomes de apresentação vinculados à versão:73movimentos/31alimentos em quatro idiomas; não são publicações humanas de nomes revisados. Busca em português/espanhol com vocabulário limitado e atalhos. Dados originais preservados. Sem fechamento integral da jornada ou de toda a tradução alimentar; recibo frontend-content-cleanup-verification.json.

### V1-026 — Tratar offline e sincronização sem fingir sucesso

**todo · V1 · L**

Como usuário, quero ler material já autorizado e saber quando um registro ainda não foi enviado.

Dependências: V1-023, V1-025

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md; docs/arquitetura/contratos-v1.md; docs/arquitetura/fluxos.md; docs/execucao/v1/trilha-implementacao.md; docs/execucao/v1/decisoes-piloto.md; docs/arquitetura/seguranca-operacao.md

Critérios de aceite:

- Cache tem versão, validade, direitos e isolamento por conta; offline não libera conteúdo bloqueado ou sem requisito/apoio necessário
- Q4:alimentação e andamento podem ser registrados offline com dados disponíveis; operação aceita no aparelho é durável e privada, com pendente/enviando/confirmado/falha/conflito explícitos
- Identidade da operação, titular, chave idempotente, payload e versão necessários sobrevivem ao processo; reenvio/reconciliação de resposta perdida não duplica consumo/sessão
- Conta diferente não lê nem envia fila alheia; logout/revogação bloqueiam acesso/envio e exclusão da conta impede reaplicar pendências em conta recriada
- Fila/cache/anexos privados têm proteção em repouso e ciclo de chaves/backup/limpeza definido, limites e falha segura de armazenamento; nenhum token no payload/log
- Conflito de revisão, rede, autorização, conteúdo retirado e dados insuficientes são distintos; não alterar silenciosamente versão/quantidade/data/fuso/dose ao reenviar
- Excluir/cancelar antes do primeiro envio invalida operações dependentes; reenvio não recria dado excluído.042 integra o ciclo de upload/arquivo conforme essa regra
- Pendente é visível e separado dos subtotais/análises confirmados; perda de conexão não vira confirmação da API ou dado inventado
- Sincronização ocorre quando o app puder executar com conexão/autorização, com retentativa limitada; não prometer execução contínua em segundo plano ou reconhecimento de foto offline

Tarefas e subtarefas:

- V1-026-T01 — Definir armazenamento e limites offline
  - Modelar fila privada durável por titular/identidade/versão e cache permitido, com proteção em repouso, limites e política de backup/limpeza
  - Definir ciclo em logout/revogação/exclusão e impedir reaplicação a novo titular no mesmo e-mail
  - Definir material disponível/permitido e estados de pendência/falha sem presumir catálogo completo ou modelo de reconhecimento local
- V1-026-T02 — Implementar envio e reconciliação
  - Persistir atomicamente antes do aceite local; reaproveitar identidade/chave ao retentar, sem novo lançamento
  - Reconciliar confirmação com resposta perdida e tratar revisão/ownership/retirada com erro explícito
  - Ordenar dependências, cancelamento/exclusão e retentativa limitada;042 integrará anexos sem recriar dados excluídos
  - Mostrar salvo no aparelho versus confirmado e proteger fila/cache na mudança de conta
- V1-026-T03 — Validar durabilidade, isolamento e recuperação
  - Encerrar/reabrir processo após aceite local e após confirmação remota com resposta perdida
  - Ensaiar reenvio, falha de armazenamento, conflito, conta trocada/revogada/excluída e exclusão concorrente em base isolada
  - Conferir separação de pendentes nos totais/análises e recuperação real no Android; registrar gate nativo iOS separado
  - Verificar exportação/exclusão/backup privados e limites antes do aceite, sem criar/apagar dados do autor por inferência

Validação: Testes de persistência/retentativa/idempotência, conflito, titularidade e falha de armazenamento; Ensaio com processo encerrado e resposta perdida em cliente/servidor reais de teste isolado; Aceite de pendência e sincronização sem duplicação, falso sucesso ou recriação de dados excluídos; Inspeção da proteção em repouso e ciclo de conta/backup pertinentes, sem tratar ACL como criptografia

Entregas: Fila durável privada e cache permitido; Estados e sincronização integrados a alimentação/andamento; Recibo de durabilidade, reconciliação, isolamento e limites

Handoff: 25/10:Q4 aprovou registrar offline e sincronizar depois. Pendência atual do formulário é em memória, sem fila durável; esta história continua todo. Não criar outra história para a mesma capacidade.042/045 integram exclusão de foto com refeição e upload sem recriação. Sem promessa de reconhecimento local, execução contínua em segundo plano ou sincronização já entregue; proteção, limites e aceites precisam ser implementados.

### V1-048 — Localizar interface e nomes alimentares com revisão

**done · V1 · L**

Como usuário, quero usar a interface em meu idioma e entender nomes alimentares traduzidos quando revisados, conservando o original e a fonte.

Dependências: V1-020, V1-021

Entradas: docs/execucao/v1/decisoes-piloto.md; docs/execucao/v1/trilha-implementacao.md; docs/execucao/v1/frontend-fidelidade-figma.md; docs/execucao/v1/escopo.md; docs/arquitetura/dominio-e-banco.md; docs/arquitetura/contratos-v1.md; docs/conteudo/evidencias-para-integracao.md

Critérios de aceite:

- Infraestrutura e textos da UI implementada em pt-BR, pt-PT, inglês e espanhol, com escolha/negociação de idioma, datas/números/plurais/erros e componentes nativos coerentes; novos fluxos usam a mesma estrutura e são conferidos na027/035
- Q5:nome traduzido é exibido quando houver tradução revisada para o idioma escolhido; nome original/idioma/fonte/versão acessíveis nos detalhes; ausência de revisão mantém original sem fingir tradução
- Traduções e aliases têm vínculo exato ao alimento/versão da fonte, idioma/localidade, versão própria, direito e registro de revisão; ficam separados do lote/hash original e não são aprovados automaticamente por IA
- Busca por nome/alias revisado retorna a mesma identidade e preserva preparo, unidade/base, nutrientes e cálculo; não mesclar alimentos homônimos ou deduzir composição regional pela tradução
- Mudar idioma não reescreve consumos antigos nem altera contratos numéricos/IDs; cache e paginação consideram idioma/versão; nome de cadastro próprio conserva declaração e privacidade do titular
- Registrar cobertura e lacunas de tradução por idioma/versão; nenhum nome de alimento/treino é inventado ou declarado revisado sem evidência; tradução de UI não implica cobertura global da base
- Testes de fallback, busca revisada, versões/retirada, idioma trocado, números/datas e texto ampliado; aceite Android dos quatro idiomas e limite nativo iOS explícito

Tarefas e subtarefas:

- V1-048-T01 — Estruturar localização da interface
  - Definir recursos e seleção/fallback de pt-BR/pt-PT/en/es com mensagens parametrizadas e plurais
  - Localizar textos dos fluxos disponíveis, erros, datas/números e controles; novos componentes não introduzem strings fora da estrutura
  - Preservar identidadeTF, semântica, layout flexível, teclado e movimento reduzido
- V1-048-T02 — Modelar e integrar nomes revisados
  - Separar tradução/alias do original importado, vinculando identidade/versão/idioma, revisão e direitos
  - Definir contratos/busca/cache e gerar Swagger a partir da implementação, sem alterar hashes/nutrientes da fonte
  - Exibir nome revisado com original/fonte acessíveis e fallback honesto; preservar nomes particulares e dados históricos
  - Publicar traduções reais apenas com revisão comprovada, sem pesquisar/contratar tradutor ou serviço pago por inferência
- V1-048-T03 — Validar identidade e experiência nos idiomas
  - Conferir nomes/preparos homônimos, tradução ausente/retirada, cache/idioma e busca sem mescla de alimentos
  - Ensaiar números/datas/plurais, erros, controles e texto ampliado nos quatro idiomas
  - Registrar recibo de cobertura da UI e conteúdo, separando fixtures técnicas, traduções revisadas e aceite humano real

Validação: Testes Go/SQL/Flutter do vínculo/alias/fallback e integridade dos dados originais; UI disponível validada nos quatro idiomas, inclusive formatos e acessibilidade; Recibo de cobertura/versões/revisão dos nomes e aceite, sem fixture como conteúdo publicado

Entregas: Estrutura e textos de UI pt-BR/pt-PT/en/es; Contrato/modelo de nomes e aliases revisados; Busca/apresentação com original/fonte e fallback; Recibo de cobertura, integridade e aceite

Handoff: 27/10:encerrada no escopo da UI disponível e capacidade de nomes revisados.495 mensagens/idioma,197 testes Flutter/analyze0,Go test/vet e SQL/HTTP descartáveis. API0.6.2/26operações; histórico/detalhe/correção usam foodDisplay fora de calculation, lote e cursor/revisão/ownership; mutações inalteradas. APK0.3.8+21 instalado/hash/assinatura conferidos; leitura realEN/PT-BR e restauração tardia de preferência após timeout confirmadas, mesma sessão sem novoGoogle/escrita alimentar. Cobertura editorial real0/6369 poridioma, fallback original; publicação real continua exigindo evidência humana/direitos. iOS nativo não executado noWindows; futuros fluxos localizam conforme forem implementados. Próxima047 pelas dependências. 29/10: pedido de interface limpa implementado e validado no APK26. Fontes/autoria/licenças/cálculos foram centralizados em Perfil > Fontes e transparência, com entrada pública por Privacidade. Nomes de apresentação vinculados à versão:73movimentos/31alimentos em quatro idiomas; não são publicações humanas de nomes revisados. Busca em português/espanhol com vocabulário limitado e atalhos. Dados originais preservados. Sem fechamento integral da jornada ou de toda a tradução alimentar; recibo frontend-content-cleanup-verification.json.

### V1-027 — Validar acessibilidade e paridade de contratos Android/iOS

**todo · V1 · M**

Como usuário de qualquer plataforma, quero uma experiência compreensível e compatível com minhas necessidades.

Dependências: V1-022, V1-024, V1-025, V1-048

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md; docs/arquitetura/contratos-v1.md; docs/arquitetura/fluxos.md; docs/execucao/v1/trilha-implementacao.md

Critérios de aceite:

- Texto ampliado, semântica, contraste, alvos de toque e movimento reduzido conferidos
- Pessoas idosas e cuidadores mantêm requisitos específicos sem seleção automática por idade
- Abstrações isolam permissões, OAuth e armazenamento; iOS não declarado testado no Windows
- Conferir fluxos implementados em pt-BR/pt-PT/en/es pela048, incluindo formatos, texto ampliado/foco e configuração em etapas/revisão; cobertura da UI separada da tradução de conteúdo

Tarefas e subtarefas:

- V1-027-T01 — Verificar Android
  - Testar TalkBack, tamanhos de fonte e fluxo com pouco conhecimento digital
  - Conferir casa/praça e cuidador praticante versus pessoa assistida
- V1-027-T02 — Preparar matriz de plataformas
  - Listar comportamento comum e diferenças nativas de cada integração
  - Manter ios/ e contrato neutro sem exigir o mesmo visual de sistema

Validação: Roteiro de acessibilidade em Android; Checklist iOS pendente até macOS/dispositivo real

Entregas: Relatório de acessibilidade; Matriz Android/iOS por funcionalidade

Handoff: Registrar arquivos/contratos alterados, comandos e resultados reais, pendências e próxima história desbloqueada em docs/execucao/v1/diario.md; atualizar este JSON, regenerar backlog e conferir mapas versionados. Concluir somente com os critérios e evidências desta história.

## EP08 — Segurança, desempenho e observabilidade

Medir e verificar o caminho real antes da distribuição, com dados sensíveis protegidos e custos controlados.

### V1-028 — Auditar dependências, segredos e superfície de ataque

**doing · V1 · L**

Como mantenedor, quero um release com riscos conhecidos em vez de um gráfico de auditoria inventado.

Dependências: V1-013, V1-021

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md; docs/arquitetura/seguranca-operacao.md; docs/arquitetura/contratos-v1.md; docs/execucao/v1/trilha-implementacao.md

Critérios de aceite:

- Inventário e análise de Go/Flutter/Android com resultados e versões reais
- govulncheck, análise estática e busca de segredos registram escopo/data e exceções
- Nenhum token, dados físicos ou mídia privada em log/artefato de build; nenhuma contagem fictícia de falhas
- Revisar fila/cache/anexos privados, proteção em repouso/ciclo de chaves/backup e exclusão coordenada aprovados noQ4; conta trocada/revogada/excluída não lê nem reaplica pendências alheias
- Revisar autorização master049 sem privilégio inferido por e-mail/cliente, provisionamento/revogação, confirmação e auditoria mínima; nenhuma conta promovida automaticamente

Tarefas e subtarefas:

- V1-028-T01 — Executar verificação
  - Rodar ferramentas suportadas e revisar reachability/impacto de achados
  - Conferir dependências nativas Android e configuração release
- V1-028-T02 — Corrigir e registrar
  - Priorizar falhas que expõem dados/autenticação e validar regressão
  - Tratar permissões mínimas, backup Android e armazenamento seguro

Validação: Relatórios reais de scanners e testes de autorização; Revisão dos logs e artefato Android

Entregas: Relatório de segurança versionado sem segredos; Riscos residuais e correções

Handoff: Registrar arquivos/contratos alterados, comandos, resultados reais, pendências e próxima história desbloqueada no diário; atualizar este JSON e derivados. Concluir somente com os critérios e evidências desta história. A auditoria24/10 é baseline histórico, não aceite integral. Govulncheckv1.9.0 Linux/Windows passou em40813941007/8331426, sem vulnerabilidades conhecidas alcançáveis detectadas; isso não certifica ausência de falhas. Gitleaks8.30.1 por digest e autorredação passou em40888675534/6894858:85não secretos verificados e0bloqueadores. Limpeza histórica especificamente autorizada aplicada somente à main com lease e backup:95commits comparados/88IDs alterados, seis arquivos, árvore atual/autores/mensagens/datas preservados e demais refs remotos inalterados. Não repetir force-push; outros clones precisam reconciliação. Histórico alcançável fechado neste recorte; caches/cópias externas e validade de tokens não certificados. Flutter/Android, offline/master e auditoria integral permanecem abertos. Sem compra/hospedagem, replay, rotação ou contato externo por inferência.

### V1-029 — Instrumentar requisições, consultas e falhas

**todo · V1 · M**

Como operador, quero descobrir onde uma jornada falhou sem registrar conteúdo pessoal.

Dependências: V1-007, V1-018

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md; docs/arquitetura/seguranca-operacao.md; docs/arquitetura/contratos-v1.md; docs/execucao/v1/trilha-implementacao.md

Critérios de aceite:

- RequestId correlaciona Flutter/API; logs estruturados com redação e cardinalidade limitada
- Métricas de latência/erro/pool e traces opcionais mostram chamadas reais; health não vaza detalhes
- Alertas/retention/custo definidos; OpenTelemetry não exige Kubernetes ou Elastic para o piloto

Tarefas e subtarefas:

- V1-029-T01 — Implementar instrumentação mínima
  - Medir duração, status, tamanho e pool sem corpo/token
  - Definir propagação e amostragem; redigir identificadores e nunca nome como label
- V1-029-T02 — Preparar diagnóstico
  - Criar roteiro usuário→HTTP→caso de uso→DB→resposta com requestId
  - Definir alertas acionáveis de erro, indisponibilidade e falha de backup

Validação: Provocar erro controlado em staging e seguir correlação; Conferir ausência de PII e excesso de cardinalidade

Entregas: Runbook e painel de métricas reais; Evidência de uma jornada rastreada

Handoff: Registrar arquivos/contratos alterados, comandos e resultados reais, pendências e próxima história desbloqueada em docs/execucao/v1/diario.md; atualizar este JSON, regenerar backlog e conferir mapas versionados. Concluir somente com os critérios e evidências desta história. 24/10: auditoria do produto registrada em auditoria-produto-2026-10-24.md. Revisão estática/contagens e cobertura não encerram a história; ver lacunas e ordem pelas dependências. Sem compra/hospedagem ou dados fictícios. 29/10: readiness0.8.1 confere objetos e privilégios com falha genérica; testesGo comuns/vet/Swagger passaram. SQL de prontidão aprovado no run40813092631 para9124a85, quatro negativos e recuperação conferidos, sem avaliação real. Não entrega métricas/traces/alertas/retention nem encerra029. 29/10: diagnósticoHTTP porcampos limitados implementado nafonte;suíteGo/vet passaram. SemURL/query/corpo/identidade;correlação do servidor. Não reiniciou avaliação, não implementaFlutter/pool/SQL/métricas/alertas/retention e não encerra029.

### V1-030 — Medir consultas e carga representativa

**todo · V1 · L**

Como responsável técnico, quero limites medidos e um plano de escala gradual.

Dependências: V1-014, V1-018, V1-020, V1-029

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md; docs/arquitetura/seguranca-operacao.md; docs/arquitetura/contratos-v1.md; docs/execucao/v1/trilha-implementacao.md

Critérios de aceite:

- Baseline registra hardware, versão, volume, cenário, p50/p95/p99, erros e saturação
- Meta inicial proposta p95 leitura abaixo de500ms e escrita abaixo de1s em staging aquecido é revista com medição
- Nenhuma alegação de milhões sem teste; otimizar paginação/índices/pool antes de dividir serviços

Tarefas e subtarefas:

- V1-030-T01 — Ensaiar carga
  - Definir mistura de catálogo, resumo, login e registros com dados de teste isolados
  - Separar carga sintética de usuários reais e não gravá-la na V1 entregue
- V1-030-T02 — Corrigir gargalos
  - Inspecionar planos de consulta e N+1 com EXPLAIN apropriado em teste
  - Medir cache/ETag e limites por instância; repetir apenas após mudança relevante

Validação: Relatório reproduzível de carga em ambiente autorizado; Teste de limite e recuperação após saturação

Entregas: Baseline e orçamento de capacidade; Plano de escala condicionado a métricas

Handoff: Registrar arquivos/contratos alterados, comandos e resultados reais, pendências e próxima história desbloqueada em docs/execucao/v1/diario.md; atualizar este JSON, regenerar backlog e conferir mapas versionados. Concluir somente com os critérios e evidências desta história. 24/10: auditoria do produto registrada em auditoria-produto-2026-10-24.md. Revisão estática/contagens e cobertura não encerram a história; ver lacunas e ordem pelas dependências. Sem compra/hospedagem ou dados fictícios.

## EP09 — Infraestrutura, CI e implantação

Subir API e banco com HTTPS, backup e rollback, após decisão concreta de fornecedor e custos.

### V1-031 — Escolher hospedagem e orçamento do piloto

**todo · V1 · S**

Como dono, quero aprovar uma opção concreta antes de criar recursos ou fornecer cartão.

Dependências: V1-007, V1-010

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md; docs/execucao/v1/implantacao-e-apk.md

Critérios de aceite:

- Comparar container Go + Postgres gerenciado com VPS, região/latência, backup, sleep, quotas e custo atual oficial
- Reutilizar conta/recurso existente se funcionar, sem prometer gratuidade permanente
- Registrar fornecedor, teto mensal, forma de cobrança, domínio e aprovação antes de provisionar

Tarefas e subtarefas:

- V1-031-T01 — Levantar o que existe
  - Listar recursos autorizados sem imprimir credenciais
  - Medir necessidades e consultar preços/limites nas páginas oficiais na data
- V1-031-T02 — Apresentar proposta concreta
  - Definir API, DB, TLS/DNS e logs com caminhos e efeitos
  - Fixar orçamento e plano de parada/exportação; aguardar aprovação para gasto/criação

Validação: Conferir preços e limites atuais com fontes oficiais; Revisar plano de desligamento e restauração

Entregas: Decisão de provedor e custos aprovada; Mapa de ambientes e região

Handoff: Registrar arquivos/contratos alterados, comandos e resultados reais, pendências e próxima história desbloqueada em docs/execucao/v1/diario.md; atualizar este JSON, regenerar backlog e conferir mapas versionados. Concluir somente com os critérios e evidências desta história.

### V1-032 — Construir pipeline e artefatos reproduzíveis

**todo · V1 · L**

Como mantenedor, quero testar a mesma versão de API, contrato e app que será distribuída.

Dependências: V1-008, V1-028

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md; docs/execucao/v1/implantacao-e-apk.md; docs/execucao/v1/trilha-implementacao.md

Critérios de aceite:

- CI roda análise/testes de Go e Flutter, migrations em DB isolado e validação documental
- Imagem não root e artefatos identificados por commit, versão e digest
- Segredos de assinatura/deploy fora do Git e não disponíveis em PR não confiável

Tarefas e subtarefas:

- V1-032-T01 — Criar jobs
  - Separar testes, contrato, import dry run e build
  - Fixar versões suportadas e cache sem credenciais
- V1-032-T02 — Versionar entrega
  - Associar commit, manifestos e schema à imagem e APK
  - Definir aprovação de deploy e retenção de artefatos

Validação: Pipeline completo no repositório autorizado; Rebuild e conferência de versão/digest

Entregas: Workflow CI; Imagem da API e metadados de release

Handoff: Registrar arquivos/contratos alterados, comandos e resultados reais, pendências e próxima história desbloqueada em docs/execucao/v1/diario.md; atualizar este JSON, regenerar backlog e conferir mapas versionados. Concluir somente com os critérios e evidências desta história. 28/10: fundação independente de CI Flutter adicionada, SDK oficial3.41.4/revisão fixa, lockfile/l10n/análise/testes/cobertura e permissões somente leitura. Primeira execução remota40690557153 aprovada para02e596b; SDK/lockfile/l10n/análise/testes/cobertura/artefato conferidos. Go/docs40690557360 também aprovado para o mesmo commit. Não encerra032 nem028: SQL em CI, imagem/artefatos e auditoria têm gates próprios. 29/10: fundação de CI SQL implementada com serviço PostgreSQL descartável, roles separadas e grants compartilhados; barreiras locais passaram. Primeira execução remota40811811519 aprovada para689f64b:13migrations/rerun0,refeições/privacidade e limpeza. Não encerra032 nem028; demais suítes/restore/artefatos próprios pendentes. 29/10: imagem não root e artefato verificados em40819933235/83b799f; ver api-image-verification.json. Não encerra032 ou028; semdeploy ou APKnovo.

### V1-033 — Implantar staging e conferir restauração

**todo · V1 · L**

Como testador, quero acessar a API do celular fora da rede do notebook.

Dependências: V1-031, V1-032, V1-006, V1-020, V1-029

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md; docs/execucao/v1/implantacao-e-apk.md

Critérios de aceite:

- API pública por HTTPS com DB privado, segredo gerenciado, CORS/proxy corretos e readiness
- Migrations e importação revisadas executadas uma vez com backup; smoke testa leitura e escrita reais
- Rollback de imagem e restauração ensaiados; apagar recursos somente após deixar de usar e preservar dados necessários

Tarefas e subtarefas:

- V1-033-T01 — Provisionar após aprovação
  - Criar ambiente com orçamento, região e acesso mínimo definidos
  - Aplicar migrations por job controlado e importar lote revisado
- V1-033-T02 — Validar fora do notebook
  - Conferir login/refresh/catálogo/registro/consulta com conta real autorizada
  - Ensaiar restore e registrar endpoint, versão, custos e desligamento

Validação: Smoke HTTPS de ponta a ponta; Restore em base separada e rollback de imagem

Entregas: URL staging e runbook; Evidência de implantação e recuperação

Handoff: Registrar arquivos/contratos alterados, comandos e resultados reais, pendências e próxima história desbloqueada em docs/execucao/v1/diario.md; atualizar este JSON, regenerar backlog e conferir mapas versionados. Concluir somente com os critérios e evidências desta história.

## EP10 — APK e primeiro teste acompanhado

Entregar um arquivo instalável legítimo, rastreável e útil para feedback real da esposa.

### V1-034 — Preparar identidade e assinatura Android

**todo · V1 · M**

Como desenvolvedor, quero que o APK de teste possa ser atualizado sem perder a instalação.

Dependências: V1-021, V1-032

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md; docs/execucao/v1/implantacao-e-apk.md; docs/execucao/v1/decisoes-piloto.md; docs/execucao/v1/trilha-implementacao.md

Critérios de aceite:

- ApplicationId próprio, versionName/code e keystore release protegido e com backup seguro
- Manifest INTERNET e network config conferidos; release usa HTTPS e assinatura própria, sem debug key
- OAuth release fingerprint configurado; segredo não entra no repo/log
- Triagem005concluida nao libera os439ativos excluidos: praticas requerem evidencia especifica/profissional e apoio conforme a fonte; nao fechar aceite integrado somente com catalogo de referencia

Tarefas e subtarefas:

- V1-034-T01 — Definir identidade
  - Escolher applicationId estável e política de versão
  - Gerar chave fora do Git com senha segura e backup recuperável
- V1-034-T02 — Validar release
  - Configurar Gradle sem segredo hardcoded e revisar permissões
  - Conferir certificado do APK, endpoint e flags debug
  - Aplicar os requisitos pertinentes também aos checkpoints intermediários de APK, documentando versão, ambiente, cenários testáveis e pendências; checkpoint não fecha o aceite integral desta história

Validação: Verificar APK com ferramenta de assinatura do SDK; Instalar e atualizar build assinada mantendo dados

Entregas: Configuração de release; Procedimento de guarda/recuperação de chave

Handoff: 23/10: certificado de avaliação release dedicado existente e protegido; cadastroOAuthAndroidrelease confirmado pelo autor, pacote/SHA1 conferidos. Apenas preparação parcial: applicationIdestável/backup de chave/HTTPS/build/instalação/atualização release ainda exigem critérios próprios e dependências; não marcar done.

### V1-035 — Validar a jornada completa da V1

**todo · V1 · L**

Como responsável pelo teste, quero evidência de que o arquivo usa API, DB e conteúdo reais.

Dependências: V1-023, V1-024, V1-025, V1-026, V1-027, V1-030, V1-033, V1-034, V1-042, V1-044, V1-045, V1-046, V1-047, V1-048, V1-049

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md; docs/execucao/v1/implantacao-e-apk.md; docs/execucao/v1/trilha-implementacao.md

Critérios de aceite:

- Login real → lote aprovado → fonte/versão → registro real → resumo → relançamento → logout verificados
- Erro/offline/duplo toque/ausência de conteúdo e troca de data cobertos sem mocks no runtime
- Lote bloqueado não executa; feedback não é apresentado como comprovação clínica
- Escolha de programa e composição controlada, além de alimento por foto revisado com quantidade informada, aceitos no recorte aprovadoQ1; ausência dessas capacidades não é escondida para fecharV1
- Visões por refeição e alimento, histórico visual, análise nutricional e dicas revisadas verificados juntos conformeQ2, sem dupla contagem ou diagnóstico por dados ausentes
- Q3:configuração completa antes da busca/seleção, trocas compatíveis/dias/horários e retomada ou parcial validados, preservando versões e registros reais
- Q4:offline durável, processo encerrado/reaberto e resposta perdida sincronizam sem duplicação; refeição/foto excluídas não reaparecem por upload/reenvio ou troca de conta
- Q5:configuração em etapas/revisão, UI nos quatro idiomas e nomes alimentares revisados/fallback aceitos sem alterar origem/identidade/nutrientes ou fingir cobertura de tradução
- Q6:toda a matriz consta do roteiro com pré-condições, resultado/evidência e disponível/incompleto/bloqueado; não concluir capacidade obrigatória ausente nem usar fixture como aceite humano
- Q6:usuário alheio não exclui registros; proprietário e master explicitamente autorizado seguem seus controles e auditoria049, preservando ciclo privado e catálogo compartilhado

Tarefas e subtarefas:

- V1-035-T01 — Executar roteiro release
  - Usar o APK assinado e API staging, não apenas flutter run
  - Conferir respostas e linhas do DB sem publicar dados pessoais
- V1-035-T02 — Fechar critérios
  - Registrar resultados por passo, versão, dispositivo e limitações
  - Corrigir bloqueadores e repetir somente trechos afetados

Validação: E2E real em Android/emulador e aparelho quando disponível; Verificação de contrato, assinatura e ausência de fixtures na distribuição

Entregas: Relatório de aceite V1; Lista de problemas e limitações

Handoff: Registrar arquivos/contratos alterados, comandos e resultados reais, pendências e próxima história desbloqueada em docs/execucao/v1/diario.md; atualizar este JSON, regenerar backlog e conferir mapas versionados. Concluir somente com os critérios e evidências desta história.

### V1-036 — Gerar e disponibilizar APK à esposa

**todo · V1 · S**

Como testadora, quero receber o arquivo e instruções claras para instalar, testar e reportar problemas.

Dependências: V1-035

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md; docs/execucao/v1/implantacao-e-apk.md; docs/execucao/v1/decisoes-piloto.md; docs/execucao/v1/trilha-implementacao.md

Critérios de aceite:

- APK release versionado, checksum, notas e link privado autorizado; sem envio de mensagem sem pedido explícito
- Guia explica instalação da origem usada, permissão temporária, atualização, login e roteiro
- Testadora concorda com uso dos dados; conta/log/arquivo temporários têm regra de limpeza após uso

Tarefas e subtarefas:

- V1-036-T01 — Empacotar
  - Build release com URL staging e manifesto aprovados
  - Gerar SHA256, verificar certificado e escrever release notes com limites
- V1-036-T02 — Preparar entrega e feedback
  - Disponibilizar arquivo/link no local aprovado e roteiro simples
  - Separar feedback de usabilidade de sintoma/prática; registrar erro/requestId sem PII
  - Aplicar os requisitos pertinentes também aos checkpoints intermediários de APK, documentando versão, ambiente, cenários testáveis e pendências; checkpoint não fecha o aceite integral desta história

Validação: Download e hash coincidem; instalação real confirmada pela testadora; Registrar feedback real, sem inventar aceitação

Entregas: APK instalável e checksum; Guia para esposa e registro de feedback

Handoff: Registrar arquivos/contratos alterados, comandos e resultados reais, pendências e próxima história desbloqueada em docs/execucao/v1/diario.md; atualizar este JSON, regenerar backlog e conferir mapas versionados. Concluir somente com os critérios e evidências desta história.

### V1-037 — Encerrar piloto e priorizar correções

**todo · V1 · S**

Como dono, quero aprender com o uso e retirar o que não for mais necessário.

Dependências: V1-036

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md; docs/execucao/v1/implantacao-e-apk.md; docs/execucao/v1/trilha-implementacao.md

Critérios de aceite:

- Consolidar problemas realmente observados por impacto e reprodução
- Excluir temporários/contas de teste e recursos dispensados somente após confirmar que não são mais usados
- Conteúdo e evidências de autoria preservados; histórico pessoal tratado conforme consentimento

Tarefas e subtarefas:

- V1-037-T01 — Avaliar feedback
  - Comparar roteiro com uso real sem gerar métricas de adesão falsas
  - Criar bugs com evidência e próximo incremento revisável
- V1-037-T02 — Fazer limpeza
  - Inventariar APKs/logs/recursos/contas ainda necessários
  - Apagar apenas alvos definidos, conferir ausência e guardar recibo sem segredos

Validação: Conferir correções com reexecução afetada; Recibo de limpeza e custo final

Entregas: Balanço do piloto; Backlog repriorizado e limpeza documentada

Handoff: Registrar arquivos/contratos alterados, comandos e resultados reais, pendências e próxima história desbloqueada em docs/execucao/v1/diario.md; atualizar este JSON, regenerar backlog e conferir mapas versionados. Concluir somente com os critérios e evidências desta história.

## EP11 — iOS e distribuição nas lojas

O mesmo produto terá iOS; execução e publicação nativa ficam depois da primeira validação Android.

### V1-038 — Compilar e testar no ecossistema iOS

**todo · V1.1 · L**

Como usuário de iPhone, quero acesso aos mesmos contratos e conteúdo permitido.

Dependências: V1-027, V1-035

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md; docs/execucao/v1/implantacao-e-apk.md; docs/execucao/v1/trilha-implementacao.md

Critérios de aceite:

- Ambiente macOS/Xcode e dispositivo/simulador reais disponíveis e documentados
- Bundle ID, OAuth, keychain, rede, permissões e lifecycle testados separadamente
- Nenhum APK convertido em IPA; mesma API/dados, adaptações nativas explícitas

Tarefas e subtarefas:

- V1-038-T01 — Preparar ambiente
  - Verificar acesso existente a Mac e compatibilidade Flutter/Xcode antes de instalação
  - Configurar assinatura/BundleID/OAuth sem expor certificados
- V1-038-T02 — Validar paridade
  - Rodar jornada real, interrupção, secure storage e acessibilidade
  - Registrar diferenças e corrigir sem forçar aparência Android

Validação: Build iOS e testes em ambiente Apple; E2E na API staging e relatório de diferenças

Entregas: Build iOS validada; Matriz de paridade atualizada

Handoff: Registrar arquivos/contratos alterados, comandos e resultados reais, pendências e próxima história desbloqueada em docs/execucao/v1/diario.md; atualizar este JSON, regenerar backlog e conferir mapas versionados. Concluir somente com os critérios e evidências desta história.

### V1-039 — Preparar TestFlight, Play e políticas de publicação

**todo · V1.1 · L**

Como responsável, quero distribuir nas lojas quando houver aceite, privacidade e custos definidos.

Dependências: V1-038, V1-037

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md; docs/execucao/v1/implantacao-e-apk.md; docs/execucao/v1/trilha-implementacao.md

Critérios de aceite:

- Contas de desenvolvedor, taxas atuais, regras de saúde/dados e revisão verificadas em fontes oficiais
- Assinatura, formulários de privacidade, screenshots reais e política de suporte coerentes
- Publicação somente após autorização; teste interno Android não exige loja agora

Tarefas e subtarefas:

- V1-039-T01 — Revisar requisitos atuais
  - Conferir Apple/Google no momento da publicação
  - Aprovar custos, identidade legal e política de dados
- V1-039-T02 — Distribuir por fases
  - Configurar testes internos/TestFlight e coletar feedback
  - Preparar rollback/retirada e submissão com versão rastreável

Validação: Checklist oficial preenchido e testes de loja reais; Sem afirmação de aprovação antes do retorno da plataforma

Entregas: Pacotes/metadata de loja; Relatório de submissão e decisões

Handoff: Registrar arquivos/contratos alterados, comandos e resultados reais, pendências e próxima história desbloqueada em docs/execucao/v1/diario.md; atualizar este JSON, regenerar backlog e conferir mapas versionados. Concluir somente com os critérios e evidências desta história.

## EP12 — Visão integral após o primeiro piloto

Preservar os requisitos ainda não implementados, sem enchê-los de simulações na V1.

### V1-040 — Ampliar modalidades, programas e personalização humana

**todo · Posterior · L**

Como usuário experiente ou iniciante, quero ampliar a biblioteca sem perder autoria nem chamar composição de programa original.

Dependências: V1-037

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md; docs/execucao/v1/trilha-implementacao.md

Critérios de aceite:

- Expandir pelos lotes N pesquisados, mantendo direitos/apoio/variante e ambiente
- Montar/importar treino próprio é complementar e registra quem alterou e a origem das peças
- Cada modalidade usa unidades e progressão reais; sem dose criada pela IA

Tarefas e subtarefas:

- V1-040-T01 — Priorizar lotes
  - Usar lacunas observadas no piloto e mapa N01–N46
  - Selecionar programas/componentes de casa, praça e academia com cobertura real
- V1-040-T02 — Implementar composição
  - Modelar alterações e atribuição por componente
  - Revisar material/instruções e liberar somente uso sustentado

Validação: Revisão dos lotes e testes de unidade/ordem; Fluxo de composição com atribuição preservada

Entregas: Lotes adicionais; Editor/importador com limites

Handoff: Registrar arquivos/contratos alterados, comandos e resultados reais, pendências e próxima história desbloqueada em docs/execucao/v1/diario.md; atualizar este JSON, regenerar backlog e conferir mapas versionados. Concluir somente com os critérios e evidências desta história. 24/10:composição controlada antecipada na044; esta história mantém expansão posterior de modalidades/lotes/importação própria sem adiar os dois caminhos aprovadosQ1.

### V1-041 — Adicionar sensores, GPS e integrações

**todo · Posterior · L**

Como usuário, quero importar medidas reais com permissão e origem, evitando registros duplicados.

Dependências: V1-037, V1-038

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md; docs/execucao/v1/trilha-implementacao.md

Critérios de aceite:

- Plataformas/provedores são escolhidos por pesquisa e capacidade real do aparelho
- Permissões graduais, revogação, identificação da origem e deduplicação testadas
- Sem frequência cardíaca/distância/calorias inventadas quando sensor não existir

Tarefas e subtarefas:

- V1-041-T01 — Definir integração prioritária
  - Comparar capacidades Android/iOS, termos e custo atuais
  - Desenhar permissionamento, consentimento e regra de conflitos
- V1-041-T02 — Implementar captura real
  - Iniciar/pausar/retomar e tratar perda de sinal/background
  - Validar unidade, precisão declarada e duplicidade com registro manual

Validação: Testes em dispositivos reais compatíveis; Negação/revogação de permissão e ausência de sensor

Entregas: Integração real documentada; Matriz de disponibilidade

Handoff: Registrar arquivos/contratos alterados, comandos e resultados reais, pendências e próxima história desbloqueada em docs/execucao/v1/diario.md; atualizar este JSON, regenerar backlog e conferir mapas versionados. Concluir somente com os critérios e evidências desta história.

### V1-043 — Desenvolver acompanhamento e alimentação avançados

**todo · Posterior · L**

Como cuidador ou usuário, quero ferramentas próprias com consentimento e limites claros.

Dependências: V1-037, V1-013

Entradas: docs/execucao/v1/escopo.md; docs/arquitetura/diagnostico-atual.md; docs/conteudo/evidencias-para-integracao.md; docs/execucao/v1/handoff.md; docs/execucao/v1/trilha-implementacao.md

Critérios de aceite:

- Pessoa assistida tem vínculo e permissões explícitos; registros distinguem autor e titular
- Modelos humanos de alimentação dependem de conteúdo/direitos e responsabilidade real, não cardápio gerado
- Reconhecimento, recomendações e contextos clínicos continuam condicionados à evidência apropriada

Tarefas e subtarefas:

- V1-043-T01 — Especificar jornadas
  - Separar saúde do cuidador de acompanhamento de outra pessoa
  - Investigar consentimento, acesso, acessibilidade e revogação em cenários reais
- V1-043-T02 — Implementar por fatia
  - Priorizar registro compartilhado e organizador alimentar conforme feedback
  - Adicionar modelo humano somente após cumprir os mesmos gates do catálogo

Validação: Teste de permissões entre titulares e cuidadores; Revisão da origem dos modelos e ausência de prescrição automática

Entregas: Jornadas de acompanhamento; Expansão alimentar com origem

Handoff: Registrar arquivos/contratos alterados, comandos e resultados reais, pendências e próxima história desbloqueada em docs/execucao/v1/diario.md; atualizar este JSON, regenerar backlog e conferir mapas versionados. Concluir somente com os critérios e evidências desta história. 24/10:cuidador pratica para si nas pausas; vínculo com pessoa assistida não é requisito daV1. Ideias de variedade/fibra/ferro exigem recorte próprio noQ2, fontes/revisão e cobertura do diário; não são diagnóstico ou meta clínica aprovados. 25/10:histórico/análise dos nutrientes registrados e dicas educativas revisadas foram antecipados paraV1 na046; aqui permanecem acompanhamento de terceiros e expansão clínica/avançada não aprovada por inferência.
